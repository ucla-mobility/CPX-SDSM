#include "RosSDSMApp.h"

#include <atomic>
#include <cstring>
#include <deque>
#include <mutex>
#include <sstream>
#include <thread>
#include <algorithm>

#ifdef _WIN32
  // Keep Windows headers predictable and enable modern socket APIs.
  #ifndef NOMINMAX
  #define NOMINMAX
  #endif
  #ifndef WIN32_LEAN_AND_MEAN
  #define WIN32_LEAN_AND_MEAN
  #endif
  // Some toolchains (e.g., MinGW) predefine _WIN32_WINNT to an older value.
  // Ensure it's high enough BEFORE including ws2tcpip.h.
  #if !defined(_WIN32_WINNT) || (_WIN32_WINNT < 0x0600)
    #undef _WIN32_WINNT
    #define _WIN32_WINNT 0x0600
  #endif
  #if !defined(WINVER) || (WINVER < 0x0600)
    #undef WINVER
    #define WINVER 0x0600
  #endif
  #include <winsock2.h>
  #include <ws2tcpip.h>
  typedef SOCKET socket_t;
  static std::atomic<int> g_wsaUsers{0};
#else
  #include <arpa/inet.h>
  #include <netinet/in.h>
  #include <sys/select.h>
  #include <sys/socket.h>
  #include <unistd.h>
  typedef int socket_t;
  #ifndef INVALID_SOCKET
  #define INVALID_SOCKET (-1)
  #endif
  #ifndef SOCKET_ERROR
  #define SOCKET_ERROR (-1)
  #endif
#endif


namespace {
static void close_socket(socket_t s) {
#ifdef _WIN32
    if (s != INVALID_SOCKET) closesocket(s);
#else
    if (s != INVALID_SOCKET) ::close(s);
#endif
}

#ifdef _WIN32
static bool wsa_startup_once() {
    int prev = g_wsaUsers.fetch_add(1);
    if (prev == 0) {
        WSADATA wsaData;
        const int rc = WSAStartup(MAKEWORD(2, 2), &wsaData);
        if (rc != 0) {
            g_wsaUsers.fetch_sub(1);
            return false;
        }
    }
    return true;
}

static void wsa_cleanup_once() {
    int left = g_wsaUsers.fetch_sub(1) - 1;
    if (left == 0) {
        WSACleanup();
    }
}
#endif
}

using namespace omnetpp;

namespace veins_ros_v2v {

Define_Module(RosSDSMApp);

RosSDSMApp::RosSDSMApp() {}

RosSDSMApp::~RosSDSMApp() {
    cancelAndDelete(sendTimer_);
    sendTimer_ = nullptr;

    if (udpPollTimer_) {
        cancelAndDelete(udpPollTimer_);
        udpPollTimer_ = nullptr;
    }
    stopUdpListener();
}

void RosSDSMApp::initialize(int stage) {
    DemoBaseApplLayer::initialize(stage);

    if (stage == 0) {
        sendInterval_ = par("sendInterval");
        sendTimer_ = new cMessage("sdsmSendTimer");
        sent_ = received_ = 0;

        // --- ROS control params ---
        rosControlEnabled_ = par("rosControlEnabled").boolValue();
        rosRemoteHost_ = par("rosRemoteHost").stdstringValue();
        rosCmdPortBase_ = par("rosCmdPortBase").intValue();
        rosRemotePort_ = par("rosRemotePort").intValue();
        rosPollInterval_ = par("rosPollInterval");
        periodicEnabled_ = par("periodicEnabled").boolValue();

        // identify this vehicle instance
        nodeIndex_ = getParentModule() ? getParentModule()->getIndex() : -1;
        localCmdPort_ = rosCmdPortBase_ + std::max(0, nodeIndex_);

        if (rosControlEnabled_) {
            udpPollTimer_ = new cMessage("rosUdpPollTimer");
            startUdpListener();
        }
    }

    if (stage == 1) {
        scheduleAt(simTime() + uniform(0.1, 0.3), sendTimer_);
        if (rosControlEnabled_ && udpPollTimer_) {
            scheduleAt(simTime() + rosPollInterval_, udpPollTimer_);
            sendToRos("HELLO node=" + std::to_string(nodeIndex_) + " cmd_port=" + std::to_string(localCmdPort_));
        }
    }
}

void RosSDSMApp::handleSelfMsg(cMessage* msg) {
    if (msg == udpPollTimer_) {
        pollUdpQueue();
        scheduleAt(simTime() + rosPollInterval_, udpPollTimer_);
        return;
    }

    if (msg == sendTimer_) {
        if (periodicEnabled_) {
            sendSdsmOnce();
        }
        scheduleAt(simTime() + sendInterval_, sendTimer_);
        return;
    }
    DemoBaseApplLayer::handleSelfMsg(msg);
}

void RosSDSMApp::sendSdsmOnce(const std::string& overridePayload) {
    // BSM beacon (DemoSafetyMessage) exists in Veins 5.2+ and is handled by onBSM()
    auto* bsm = new veins::DemoSafetyMessage("SDSM_BSM");
    populateWSM(bsm);
    bsm->setTimestamp(simTime());

    std::string payloadStr;
    if (!overridePayload.empty()) {
        payloadStr = overridePayload;
    } else {
        // Build a minimal SDSM-like payload (string) and encapsulate it
        const auto pos = mobility->getPositionAt(simTime());
        const double spd = mobility->getSpeed();

        std::ostringstream oss;
        oss << "SensorDataSharingMessage{" 
            << "veh=\"" << getParentModule()->getFullName() << "\"" 
            << ",t=" << simTime().dbl()
            << ",x=" << pos.x
            << ",y=" << pos.y
            << ",speed=" << spd
            << "}";
        payloadStr = oss.str();
    }

    auto* payload = new veins_ros_v2v::messages::SdsmPayload("sdsmPayload");
    payload->setPayload(payloadStr.c_str());
    bsm->encapsulate(payload);

    sendDown(bsm);
    sent_++;

    if (rosControlEnabled_) {
        sendToRos("TX node=" + std::to_string(nodeIndex_) + " t=" + std::to_string(simTime().dbl()) + " payload=" + payloadStr);
    }
}

void RosSDSMApp::onBSM(veins::DemoSafetyMessage* bsm) {
    received_++;

    const simtime_t lat = simTime() - bsm->getTimestamp();

    // Our payload is encapsulated inside the BSM
    const cPacket* enc = bsm->getEncapsulatedPacket();
    if (enc) {
        auto* p = check_and_cast<const veins_ros_v2v::messages::SdsmPayload*>(enc);
        EV_INFO << "[RosSDSMApp] RX BSM latency=" << lat
                << " payload=\"" << p->getPayload() << "\"\n";

        if (rosControlEnabled_) {
            std::ostringstream oss;
            oss << "RX node=" << nodeIndex_ << " t=" << simTime().dbl() << " latency=" << lat.dbl() << " payload=" << p->getPayload();
            sendToRos(oss.str());
        }
    } else {
        EV_INFO << "[RosSDSMApp] RX BSM latency=" << lat
                << " (no encapsulated payload)\n";
        if (rosControlEnabled_) {
            std::ostringstream oss;
            oss << "RX node=" << nodeIndex_ << " t=" << simTime().dbl() << " latency=" << lat.dbl() << " payload=<none>";
            sendToRos(oss.str());
        }
    }
}

void RosSDSMApp::finish() {
    recordScalar("sdsm_sent", sent_);
    recordScalar("sdsm_received", received_);
    DemoBaseApplLayer::finish();
}

// ------------------------------------------------------------------
// ROS control via UDP (external process)
// ------------------------------------------------------------------

void RosSDSMApp::startUdpListener() {
    if (udpRunning_.load()) return;

#ifdef _WIN32
    if (!wsa_startup_once()) {
        EV_WARN << "[RosSDSMApp] WSAStartup failed, disabling rosControlEnabled\n";
        rosControlEnabled_ = false;
        return;
    }
#endif

    udpRunning_.store(true);
    udpThread_ = std::thread(&RosSDSMApp::udpThreadMain, this);
}

void RosSDSMApp::stopUdpListener() {
    if (!udpRunning_.load()) return;
    udpRunning_.store(false);
    if (udpThread_.joinable()) udpThread_.join();

#ifdef _WIN32
    wsa_cleanup_once();
#endif
}

void RosSDSMApp::udpThreadMain() {
    socket_t sock = INVALID_SOCKET;

    sock = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == INVALID_SOCKET) {
        return;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(static_cast<uint16_t>(localCmdPort_));

    if (::bind(sock, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == SOCKET_ERROR) {
        close_socket(sock);
        return;
    }

    // poll with select() so the thread can exit quickly
    while (udpRunning_.load()) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(sock, &rfds);

        timeval tv{};
        tv.tv_sec = 0;
        tv.tv_usec = 200 * 1000; // 200ms

        const int rv = ::select(static_cast<int>(sock + 1), &rfds, nullptr, nullptr, &tv);
        if (rv <= 0) continue;

        if (FD_ISSET(sock, &rfds)) {
            char buf[2048];
            sockaddr_in src{};
#ifdef _WIN32
            int srclen = sizeof(src);
#else
            socklen_t srclen = sizeof(src);
#endif
            const int n = ::recvfrom(sock, buf, sizeof(buf) - 1, 0, reinterpret_cast<sockaddr*>(&src), &srclen);
            if (n > 0) {
                buf[n] = '\0';
                std::string line(buf);
                // drop CRLF
                while (!line.empty() && (line.back() == '\n' || line.back() == '\r')) line.pop_back();
                {
                    std::lock_guard<std::mutex> lk(udpMtx_);
                    udpQueue_.push_back(line);
                }
            }
        }
    }

    close_socket(sock);
}

void RosSDSMApp::pollUdpQueue() {
    std::deque<std::string> q;
    {
        std::lock_guard<std::mutex> lk(udpMtx_);
        q.swap(udpQueue_);
    }
    for (const auto& line : q) {
        handleCommandLine(line);
    }
}

void RosSDSMApp::handleCommandLine(const std::string& line) {
    // Very small command language (space-separated):
    //   SEND_BSM <payload...>
    //   SET_INTERVAL <seconds>
    //   ENABLE_PERIODIC <0|1>
    //   PING

    std::istringstream iss(line);
    std::string cmd;
    iss >> cmd;
    if (cmd.empty()) return;

    if (cmd == "PING") {
        sendToRos("PONG node=" + std::to_string(nodeIndex_));
        return;
    }

    if (cmd == "SEND" || cmd == "SEND_BSM") {
        std::string rest;
        std::getline(iss, rest);
        // trim leading spaces
        while (!rest.empty() && rest.front() == ' ') rest.erase(rest.begin());
        sendSdsmOnce(rest);
        sendToRos("ACK node=" + std::to_string(nodeIndex_) + " cmd=SEND_BSM ok=1");
        return;
    }

    if (cmd == "SET_INTERVAL") {
        double sec = 0.0;
        iss >> sec;
        if (sec > 0) {
            sendInterval_ = sec;
            sendToRos("ACK node=" + std::to_string(nodeIndex_) + " cmd=SET_INTERVAL sec=" + std::to_string(sec) + " ok=1");
        } else {
            sendToRos("ACK node=" + std::to_string(nodeIndex_) + " cmd=SET_INTERVAL ok=0");
        }
        return;
    }

    if (cmd == "ENABLE_PERIODIC") {
        int v = 0;
        iss >> v;
        periodicEnabled_ = (v != 0);
        sendToRos("ACK node=" + std::to_string(nodeIndex_) + " cmd=ENABLE_PERIODIC v=" + std::to_string(v) + " ok=1");
        return;
    }

    sendToRos("ACK node=" + std::to_string(nodeIndex_) + " cmd=UNKNOWN ok=0 line=\"" + line + "\"");
}

void RosSDSMApp::sendToRos(const std::string& line) {
    // Best-effort UDP send to ROS listener (single port)
    socket_t sock = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == INVALID_SOCKET) {
        return;
    }

    sockaddr_in dst{};
    dst.sin_family = AF_INET;
    dst.sin_port = htons(static_cast<uint16_t>(rosRemotePort_));

    // Parse dotted IPv4 string.
#ifdef _WIN32
    // Use inet_addr for maximum compatibility across Windows toolchains.
    const unsigned long addr = ::inet_addr(rosRemoteHost_.c_str());
    if (addr == INADDR_NONE) {
        close_socket(sock);
        return;
    }
    dst.sin_addr.s_addr = addr;
#else
    if (::inet_pton(AF_INET, rosRemoteHost_.c_str(), &dst.sin_addr) != 1) {
        close_socket(sock);
        return;
    }
#endif

    const int rc = ::sendto(
        sock,
        line.c_str(),
        static_cast<int>(line.size()),
        0,
        reinterpret_cast<sockaddr*>(&dst),
        static_cast<int>(sizeof(dst))
    );
    (void)rc;

    close_socket(sock);
}

} // namespace veins_ros_v2v
