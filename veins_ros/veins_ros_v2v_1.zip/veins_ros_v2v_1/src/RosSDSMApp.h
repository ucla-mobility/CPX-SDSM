#ifndef __VEINS_ROS_V2V_ROSSDSMAPP_H_
#define __VEINS_ROS_V2V_ROSSDSMAPP_H_

#include <omnetpp.h>
#include <atomic>
#include <deque>
#include <mutex>
#include <thread>

#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"
#include "veins/modules/messages/DemoSafetyMessage_m.h"
#include "messages/SdsmPayload_m.h"

namespace veins_ros_v2v {

/**
 * Minimal V2V demo app (Veins 5.2+):
 * - Every vehicle periodically broadcasts a DemoSafetyMessage (BSM beacon)
 * - We attach our own payload by encapsulating a SdsmPayload packet into the BSM
 * - Receivers log payload and one-way latency (simTime - timestamp)
 */
class RosSDSMApp : public veins::DemoBaseApplLayer {
public:
    RosSDSMApp();
    virtual ~RosSDSMApp();

protected:
    virtual void initialize(int stage) override;
    virtual void finish() override;

    virtual void onBSM(veins::DemoSafetyMessage* bsm) override;
    virtual void handleSelfMsg(cMessage* msg) override;

private:
    void sendSdsmOnce(const std::string& overridePayload = "");

    // --- ROS control via UDP (external process) ---
    void startUdpListener();
    void stopUdpListener();
    void udpThreadMain();
    void pollUdpQueue();
    void handleCommandLine(const std::string& line);
    void sendToRos(const std::string& line);

    // Parameters
    bool rosControlEnabled_ = true;
    std::string rosRemoteHost_;
    int rosCmdPortBase_ = 50000;   // each vehicle binds (base + index)
    int rosRemotePort_ = 50010;    // ROS node listens here for RX/TX/ACK
    simtime_t rosPollInterval_ = 0.05;
    bool periodicEnabled_ = true;

    // UDP runtime state
    int localCmdPort_ = -1;
    int nodeIndex_ = -1;
    std::atomic<bool> udpRunning_{false};
    std::thread udpThread_;
    std::mutex udpMtx_;
    std::deque<std::string> udpQueue_;
    cMessage* udpPollTimer_ = nullptr;

private:
    cMessage* sendTimer_ = nullptr;
    simtime_t sendInterval_;
    long sent_ = 0;
    long received_ = 0;
};

} // namespace veins_ros_v2v

#endif
