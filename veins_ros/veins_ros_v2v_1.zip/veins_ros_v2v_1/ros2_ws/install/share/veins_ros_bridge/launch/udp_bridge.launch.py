from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='veins_ros_bridge',
            executable='udp_bridge',
            name='veins_udp_bridge',
            output='screen',
            parameters=[{
                'host': '127.0.0.1',
                'cmd_port_base': 50000,
                'ros_rx_port': 50010,
                'default_target_id': 0,
                'sdsm_target_id': 0,
            }],
        )
    ])
