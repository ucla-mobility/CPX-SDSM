// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\PositionOffsetXYZ.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position_offset_xyz.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__PositionOffsetXYZ __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__PositionOffsetXYZ __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PositionOffsetXYZ_
{
  using Type = PositionOffsetXYZ_<ContainerAllocator>;

  explicit PositionOffsetXYZ_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->offset_x = 0;
      this->offset_y = 0;
      this->offset_z = 0;
      this->has_offset_z = false;
    }
  }

  explicit PositionOffsetXYZ_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->offset_x = 0;
      this->offset_y = 0;
      this->offset_z = 0;
      this->has_offset_z = false;
    }
  }

  // field types and members
  using _offset_x_type =
    int16_t;
  _offset_x_type offset_x;
  using _offset_y_type =
    int16_t;
  _offset_y_type offset_y;
  using _offset_z_type =
    int16_t;
  _offset_z_type offset_z;
  using _has_offset_z_type =
    bool;
  _has_offset_z_type has_offset_z;

  // setters for named parameter idiom
  Type & set__offset_x(
    const int16_t & _arg)
  {
    this->offset_x = _arg;
    return *this;
  }
  Type & set__offset_y(
    const int16_t & _arg)
  {
    this->offset_y = _arg;
    return *this;
  }
  Type & set__offset_z(
    const int16_t & _arg)
  {
    this->offset_z = _arg;
    return *this;
  }
  Type & set__has_offset_z(
    const bool & _arg)
  {
    this->has_offset_z = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__PositionOffsetXYZ
    std::shared_ptr<sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__PositionOffsetXYZ
    std::shared_ptr<sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PositionOffsetXYZ_ & other) const
  {
    if (this->offset_x != other.offset_x) {
      return false;
    }
    if (this->offset_y != other.offset_y) {
      return false;
    }
    if (this->offset_z != other.offset_z) {
      return false;
    }
    if (this->has_offset_z != other.has_offset_z) {
      return false;
    }
    return true;
  }
  bool operator!=(const PositionOffsetXYZ_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PositionOffsetXYZ_

// alias to use template instance with default allocator
using PositionOffsetXYZ =
  sdsm_msgs::msg::PositionOffsetXYZ_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__STRUCT_HPP_
