// generated from rosidl_generator_c/resource/idl.h.em
// with input from sdsm_msgs:msg\DetectedVehicleData.idl
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__DETECTED_VEHICLE_DATA_H_
#define SDSM_MSGS__MSG__DETECTED_VEHICLE_DATA_H_

#include "sdsm_msgs/msg/detail/detected_vehicle_data__struct.h"
#include "sdsm_msgs/msg/detail/detected_vehicle_data__functions.h"
#include "sdsm_msgs/msg/detail/detected_vehicle_data__type_support.h"

#endif  // SDSM_MSGS__MSG__DETECTED_VEHICLE_DATA_H_
