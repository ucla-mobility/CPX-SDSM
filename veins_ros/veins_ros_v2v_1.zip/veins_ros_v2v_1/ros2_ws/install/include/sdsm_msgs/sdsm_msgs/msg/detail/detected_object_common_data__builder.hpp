// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\DetectedObjectCommonData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_object_common_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/detected_object_common_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_DetectedObjectCommonData_heading
{
public:
  explicit Init_DetectedObjectCommonData_heading(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::DetectedObjectCommonData heading(::sdsm_msgs::msg::DetectedObjectCommonData::_heading_type arg)
  {
    msg_.heading = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_has_speed_z
{
public:
  explicit Init_DetectedObjectCommonData_has_speed_z(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  Init_DetectedObjectCommonData_heading has_speed_z(::sdsm_msgs::msg::DetectedObjectCommonData::_has_speed_z_type arg)
  {
    msg_.has_speed_z = std::move(arg);
    return Init_DetectedObjectCommonData_heading(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_speed_z
{
public:
  explicit Init_DetectedObjectCommonData_speed_z(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  Init_DetectedObjectCommonData_has_speed_z speed_z(::sdsm_msgs::msg::DetectedObjectCommonData::_speed_z_type arg)
  {
    msg_.speed_z = std::move(arg);
    return Init_DetectedObjectCommonData_has_speed_z(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_speed
{
public:
  explicit Init_DetectedObjectCommonData_speed(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  Init_DetectedObjectCommonData_speed_z speed(::sdsm_msgs::msg::DetectedObjectCommonData::_speed_type arg)
  {
    msg_.speed = std::move(arg);
    return Init_DetectedObjectCommonData_speed_z(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_pos_confidence
{
public:
  explicit Init_DetectedObjectCommonData_pos_confidence(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  Init_DetectedObjectCommonData_speed pos_confidence(::sdsm_msgs::msg::DetectedObjectCommonData::_pos_confidence_type arg)
  {
    msg_.pos_confidence = std::move(arg);
    return Init_DetectedObjectCommonData_speed(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_pos
{
public:
  explicit Init_DetectedObjectCommonData_pos(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  Init_DetectedObjectCommonData_pos_confidence pos(::sdsm_msgs::msg::DetectedObjectCommonData::_pos_type arg)
  {
    msg_.pos = std::move(arg);
    return Init_DetectedObjectCommonData_pos_confidence(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_measurement_time
{
public:
  explicit Init_DetectedObjectCommonData_measurement_time(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  Init_DetectedObjectCommonData_pos measurement_time(::sdsm_msgs::msg::DetectedObjectCommonData::_measurement_time_type arg)
  {
    msg_.measurement_time = std::move(arg);
    return Init_DetectedObjectCommonData_pos(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_object_id
{
public:
  explicit Init_DetectedObjectCommonData_object_id(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  Init_DetectedObjectCommonData_measurement_time object_id(::sdsm_msgs::msg::DetectedObjectCommonData::_object_id_type arg)
  {
    msg_.object_id = std::move(arg);
    return Init_DetectedObjectCommonData_measurement_time(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_obj_type_cfd
{
public:
  explicit Init_DetectedObjectCommonData_obj_type_cfd(::sdsm_msgs::msg::DetectedObjectCommonData & msg)
  : msg_(msg)
  {}
  Init_DetectedObjectCommonData_object_id obj_type_cfd(::sdsm_msgs::msg::DetectedObjectCommonData::_obj_type_cfd_type arg)
  {
    msg_.obj_type_cfd = std::move(arg);
    return Init_DetectedObjectCommonData_object_id(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

class Init_DetectedObjectCommonData_obj_type
{
public:
  Init_DetectedObjectCommonData_obj_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DetectedObjectCommonData_obj_type_cfd obj_type(::sdsm_msgs::msg::DetectedObjectCommonData::_obj_type_type arg)
  {
    msg_.obj_type = std::move(arg);
    return Init_DetectedObjectCommonData_obj_type_cfd(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObjectCommonData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::DetectedObjectCommonData>()
{
  return sdsm_msgs::msg::builder::Init_DetectedObjectCommonData_obj_type();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__BUILDER_HPP_
