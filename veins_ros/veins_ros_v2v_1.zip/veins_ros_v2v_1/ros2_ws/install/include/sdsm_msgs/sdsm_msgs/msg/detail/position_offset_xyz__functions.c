// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sdsm_msgs:msg\PositionOffsetXYZ.idl
// generated code does not contain a copyright notice
#include "sdsm_msgs/msg/detail/position_offset_xyz__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
sdsm_msgs__msg__PositionOffsetXYZ__init(sdsm_msgs__msg__PositionOffsetXYZ * msg)
{
  if (!msg) {
    return false;
  }
  // offset_x
  // offset_y
  // offset_z
  // has_offset_z
  return true;
}

void
sdsm_msgs__msg__PositionOffsetXYZ__fini(sdsm_msgs__msg__PositionOffsetXYZ * msg)
{
  if (!msg) {
    return;
  }
  // offset_x
  // offset_y
  // offset_z
  // has_offset_z
}

bool
sdsm_msgs__msg__PositionOffsetXYZ__are_equal(const sdsm_msgs__msg__PositionOffsetXYZ * lhs, const sdsm_msgs__msg__PositionOffsetXYZ * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // offset_x
  if (lhs->offset_x != rhs->offset_x) {
    return false;
  }
  // offset_y
  if (lhs->offset_y != rhs->offset_y) {
    return false;
  }
  // offset_z
  if (lhs->offset_z != rhs->offset_z) {
    return false;
  }
  // has_offset_z
  if (lhs->has_offset_z != rhs->has_offset_z) {
    return false;
  }
  return true;
}

bool
sdsm_msgs__msg__PositionOffsetXYZ__copy(
  const sdsm_msgs__msg__PositionOffsetXYZ * input,
  sdsm_msgs__msg__PositionOffsetXYZ * output)
{
  if (!input || !output) {
    return false;
  }
  // offset_x
  output->offset_x = input->offset_x;
  // offset_y
  output->offset_y = input->offset_y;
  // offset_z
  output->offset_z = input->offset_z;
  // has_offset_z
  output->has_offset_z = input->has_offset_z;
  return true;
}

sdsm_msgs__msg__PositionOffsetXYZ *
sdsm_msgs__msg__PositionOffsetXYZ__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__PositionOffsetXYZ * msg = (sdsm_msgs__msg__PositionOffsetXYZ *)allocator.allocate(sizeof(sdsm_msgs__msg__PositionOffsetXYZ), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sdsm_msgs__msg__PositionOffsetXYZ));
  bool success = sdsm_msgs__msg__PositionOffsetXYZ__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sdsm_msgs__msg__PositionOffsetXYZ__destroy(sdsm_msgs__msg__PositionOffsetXYZ * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sdsm_msgs__msg__PositionOffsetXYZ__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sdsm_msgs__msg__PositionOffsetXYZ__Sequence__init(sdsm_msgs__msg__PositionOffsetXYZ__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__PositionOffsetXYZ * data = NULL;

  if (size) {
    data = (sdsm_msgs__msg__PositionOffsetXYZ *)allocator.zero_allocate(size, sizeof(sdsm_msgs__msg__PositionOffsetXYZ), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sdsm_msgs__msg__PositionOffsetXYZ__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sdsm_msgs__msg__PositionOffsetXYZ__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sdsm_msgs__msg__PositionOffsetXYZ__Sequence__fini(sdsm_msgs__msg__PositionOffsetXYZ__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sdsm_msgs__msg__PositionOffsetXYZ__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sdsm_msgs__msg__PositionOffsetXYZ__Sequence *
sdsm_msgs__msg__PositionOffsetXYZ__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__PositionOffsetXYZ__Sequence * array = (sdsm_msgs__msg__PositionOffsetXYZ__Sequence *)allocator.allocate(sizeof(sdsm_msgs__msg__PositionOffsetXYZ__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sdsm_msgs__msg__PositionOffsetXYZ__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sdsm_msgs__msg__PositionOffsetXYZ__Sequence__destroy(sdsm_msgs__msg__PositionOffsetXYZ__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sdsm_msgs__msg__PositionOffsetXYZ__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sdsm_msgs__msg__PositionOffsetXYZ__Sequence__are_equal(const sdsm_msgs__msg__PositionOffsetXYZ__Sequence * lhs, const sdsm_msgs__msg__PositionOffsetXYZ__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sdsm_msgs__msg__PositionOffsetXYZ__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sdsm_msgs__msg__PositionOffsetXYZ__Sequence__copy(
  const sdsm_msgs__msg__PositionOffsetXYZ__Sequence * input,
  sdsm_msgs__msg__PositionOffsetXYZ__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sdsm_msgs__msg__PositionOffsetXYZ);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    sdsm_msgs__msg__PositionOffsetXYZ * data =
      (sdsm_msgs__msg__PositionOffsetXYZ *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sdsm_msgs__msg__PositionOffsetXYZ__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          sdsm_msgs__msg__PositionOffsetXYZ__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sdsm_msgs__msg__PositionOffsetXYZ__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
