// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\DetectedObstacleData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_obstacle_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/detected_obstacle_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_DetectedObstacleData_obst_size
{
public:
  Init_DetectedObstacleData_obst_size()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::sdsm_msgs::msg::DetectedObstacleData obst_size(::sdsm_msgs::msg::DetectedObstacleData::_obst_size_type arg)
  {
    msg_.obst_size = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedObstacleData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::DetectedObstacleData>()
{
  return sdsm_msgs::msg::builder::Init_DetectedObstacleData_obst_size();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__BUILDER_HPP_
