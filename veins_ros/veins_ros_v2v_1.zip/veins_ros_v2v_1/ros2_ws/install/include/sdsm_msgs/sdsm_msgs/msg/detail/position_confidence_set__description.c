// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\PositionConfidenceSet.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/position_confidence_set__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__PositionConfidenceSet__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xfc, 0x2c, 0x18, 0xaf, 0x56, 0x15, 0x84, 0xb6,
      0xd4, 0x95, 0xce, 0x73, 0x9c, 0x8d, 0x72, 0x38,
      0x77, 0x76, 0x95, 0xf5, 0xf3, 0xe2, 0x09, 0x5b,
      0xd2, 0x2f, 0x64, 0xfa, 0x6f, 0x57, 0x5c, 0x73,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char sdsm_msgs__msg__PositionConfidenceSet__TYPE_NAME[] = "sdsm_msgs/msg/PositionConfidenceSet";

// Define type names, field names, and default values
static char sdsm_msgs__msg__PositionConfidenceSet__FIELD_NAME__pos_confidence[] = "pos_confidence";
static char sdsm_msgs__msg__PositionConfidenceSet__FIELD_NAME__elevation_confidence[] = "elevation_confidence";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__PositionConfidenceSet__FIELDS[] = {
  {
    {sdsm_msgs__msg__PositionConfidenceSet__FIELD_NAME__pos_confidence, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__PositionConfidenceSet__FIELD_NAME__elevation_confidence, 20, 20},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__PositionConfidenceSet__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__PositionConfidenceSet__TYPE_NAME, 35, 35},
      {sdsm_msgs__msg__PositionConfidenceSet__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Position confidence (J2735)\n"
  "# Indicates accuracy of position measurements; higher values = better confidence\n"
  "# Placeholder structure; full J2735 confidence enums deferred to ORANGE fields\n"
  "\n"
  "uint8 pos_confidence  # 0=unavailable\n"
  "uint8 elevation_confidence  # 0=unavailable";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__PositionConfidenceSet__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__PositionConfidenceSet__TYPE_NAME, 35, 35},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 273, 273},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__PositionConfidenceSet__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__PositionConfidenceSet__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
