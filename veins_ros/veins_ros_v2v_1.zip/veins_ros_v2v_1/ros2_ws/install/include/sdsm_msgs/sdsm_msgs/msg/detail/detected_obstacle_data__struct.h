// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\DetectedObstacleData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_obstacle_data.h"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'obst_size'
#include "sdsm_msgs/msg/detail/obstacle_size__struct.h"

/// Struct defined in msg/DetectedObstacleData in the package sdsm_msgs.
/**
  * Obstacle-specific data
 */
typedef struct sdsm_msgs__msg__DetectedObstacleData
{
  sdsm_msgs__msg__ObstacleSize obst_size;
} sdsm_msgs__msg__DetectedObstacleData;

// Struct for a sequence of sdsm_msgs__msg__DetectedObstacleData.
typedef struct sdsm_msgs__msg__DetectedObstacleData__Sequence
{
  sdsm_msgs__msg__DetectedObstacleData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__DetectedObstacleData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__STRUCT_H_
