// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\DDateTime.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/d_date_time.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__DDateTime __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__DDateTime __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DDateTime_
{
  using Type = DDateTime_<ContainerAllocator>;

  explicit DDateTime_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->day_of_month = 0;
      this->time_of_day = 0ul;
    }
  }

  explicit DDateTime_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->day_of_month = 0;
      this->time_of_day = 0ul;
    }
  }

  // field types and members
  using _day_of_month_type =
    uint8_t;
  _day_of_month_type day_of_month;
  using _time_of_day_type =
    uint32_t;
  _time_of_day_type time_of_day;

  // setters for named parameter idiom
  Type & set__day_of_month(
    const uint8_t & _arg)
  {
    this->day_of_month = _arg;
    return *this;
  }
  Type & set__time_of_day(
    const uint32_t & _arg)
  {
    this->time_of_day = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::DDateTime_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::DDateTime_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DDateTime_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DDateTime_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DDateTime_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DDateTime_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DDateTime_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DDateTime_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DDateTime_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DDateTime_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__DDateTime
    std::shared_ptr<sdsm_msgs::msg::DDateTime_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__DDateTime
    std::shared_ptr<sdsm_msgs::msg::DDateTime_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DDateTime_ & other) const
  {
    if (this->day_of_month != other.day_of_month) {
      return false;
    }
    if (this->time_of_day != other.time_of_day) {
      return false;
    }
    return true;
  }
  bool operator!=(const DDateTime_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DDateTime_

// alias to use template instance with default allocator
using DDateTime =
  sdsm_msgs::msg::DDateTime_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__STRUCT_HPP_
