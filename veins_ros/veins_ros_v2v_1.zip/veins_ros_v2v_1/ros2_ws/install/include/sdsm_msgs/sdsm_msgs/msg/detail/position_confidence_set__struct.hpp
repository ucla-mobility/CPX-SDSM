// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\PositionConfidenceSet.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position_confidence_set.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__PositionConfidenceSet __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__PositionConfidenceSet __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PositionConfidenceSet_
{
  using Type = PositionConfidenceSet_<ContainerAllocator>;

  explicit PositionConfidenceSet_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pos_confidence = 0;
      this->elevation_confidence = 0;
    }
  }

  explicit PositionConfidenceSet_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pos_confidence = 0;
      this->elevation_confidence = 0;
    }
  }

  // field types and members
  using _pos_confidence_type =
    uint8_t;
  _pos_confidence_type pos_confidence;
  using _elevation_confidence_type =
    uint8_t;
  _elevation_confidence_type elevation_confidence;

  // setters for named parameter idiom
  Type & set__pos_confidence(
    const uint8_t & _arg)
  {
    this->pos_confidence = _arg;
    return *this;
  }
  Type & set__elevation_confidence(
    const uint8_t & _arg)
  {
    this->elevation_confidence = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__PositionConfidenceSet
    std::shared_ptr<sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__PositionConfidenceSet
    std::shared_ptr<sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PositionConfidenceSet_ & other) const
  {
    if (this->pos_confidence != other.pos_confidence) {
      return false;
    }
    if (this->elevation_confidence != other.elevation_confidence) {
      return false;
    }
    return true;
  }
  bool operator!=(const PositionConfidenceSet_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PositionConfidenceSet_

// alias to use template instance with default allocator
using PositionConfidenceSet =
  sdsm_msgs::msg::PositionConfidenceSet_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__STRUCT_HPP_
