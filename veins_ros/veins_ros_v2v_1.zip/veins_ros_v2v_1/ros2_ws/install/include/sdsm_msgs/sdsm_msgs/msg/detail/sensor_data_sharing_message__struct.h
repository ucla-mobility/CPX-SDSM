// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\SensorDataSharingMessage.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/sensor_data_sharing_message.h"


#ifndef SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'EQUIPMENT_TYPE_UNKNOWN'.
enum
{
  sdsm_msgs__msg__SensorDataSharingMessage__EQUIPMENT_TYPE_UNKNOWN = 0
};

/// Constant 'EQUIPMENT_TYPE_RSU'.
enum
{
  sdsm_msgs__msg__SensorDataSharingMessage__EQUIPMENT_TYPE_RSU = 1
};

/// Constant 'EQUIPMENT_TYPE_OBU'.
enum
{
  sdsm_msgs__msg__SensorDataSharingMessage__EQUIPMENT_TYPE_OBU = 2
};

/// Constant 'EQUIPMENT_TYPE_VRU'.
enum
{
  sdsm_msgs__msg__SensorDataSharingMessage__EQUIPMENT_TYPE_VRU = 3
};

// Include directives for member types
// Member 'sdsm_time_stamp'
#include "sdsm_msgs/msg/detail/d_date_time__struct.h"
// Member 'ref_pos'
#include "sdsm_msgs/msg/detail/position3_d__struct.h"
// Member 'objects'
#include "sdsm_msgs/msg/detail/detected_object_data__struct.h"

/// Struct defined in msg/SensorDataSharingMessage in the package sdsm_msgs.
/**
  * SAE J3224 Sensor Data Sharing Message
 */
typedef struct sdsm_msgs__msg__SensorDataSharingMessage
{
  /// Message count (0-127, wraps per J2735)
  /// Sequence number for message ordering and duplicate detection
  uint8_t msg_cnt;
  /// Temporary ID of sender (4 bytes)
  /// Anonymized identifier for privacy; changes periodically
  uint8_t source_id[4];
  /// Equipment type (use EQUIPMENT_TYPE_* constants)
  /// Identifies sender as RSU, OBU, or VRU device
  uint8_t equipment_type;
  sdsm_msgs__msg__DDateTime sdsm_time_stamp;
  sdsm_msgs__msg__Position3D ref_pos;
  /// Detected objects (1-256 per J3224)
  /// Array length must be validated: 1 <= len(objects) <= 256
  sdsm_msgs__msg__DetectedObjectData__Sequence objects;
} sdsm_msgs__msg__SensorDataSharingMessage;

// Struct for a sequence of sdsm_msgs__msg__SensorDataSharingMessage.
typedef struct sdsm_msgs__msg__SensorDataSharingMessage__Sequence
{
  sdsm_msgs__msg__SensorDataSharingMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__SensorDataSharingMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__STRUCT_H_
