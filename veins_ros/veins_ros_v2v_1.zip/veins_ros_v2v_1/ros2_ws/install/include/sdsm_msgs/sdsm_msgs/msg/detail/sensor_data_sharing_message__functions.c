// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sdsm_msgs:msg\SensorDataSharingMessage.idl
// generated code does not contain a copyright notice
#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `sdsm_time_stamp`
#include "sdsm_msgs/msg/detail/d_date_time__functions.h"
// Member `ref_pos`
#include "sdsm_msgs/msg/detail/position3_d__functions.h"
// Member `objects`
#include "sdsm_msgs/msg/detail/detected_object_data__functions.h"

bool
sdsm_msgs__msg__SensorDataSharingMessage__init(sdsm_msgs__msg__SensorDataSharingMessage * msg)
{
  if (!msg) {
    return false;
  }
  // msg_cnt
  // source_id
  // equipment_type
  // sdsm_time_stamp
  if (!sdsm_msgs__msg__DDateTime__init(&msg->sdsm_time_stamp)) {
    sdsm_msgs__msg__SensorDataSharingMessage__fini(msg);
    return false;
  }
  // ref_pos
  if (!sdsm_msgs__msg__Position3D__init(&msg->ref_pos)) {
    sdsm_msgs__msg__SensorDataSharingMessage__fini(msg);
    return false;
  }
  // objects
  if (!sdsm_msgs__msg__DetectedObjectData__Sequence__init(&msg->objects, 0)) {
    sdsm_msgs__msg__SensorDataSharingMessage__fini(msg);
    return false;
  }
  return true;
}

void
sdsm_msgs__msg__SensorDataSharingMessage__fini(sdsm_msgs__msg__SensorDataSharingMessage * msg)
{
  if (!msg) {
    return;
  }
  // msg_cnt
  // source_id
  // equipment_type
  // sdsm_time_stamp
  sdsm_msgs__msg__DDateTime__fini(&msg->sdsm_time_stamp);
  // ref_pos
  sdsm_msgs__msg__Position3D__fini(&msg->ref_pos);
  // objects
  sdsm_msgs__msg__DetectedObjectData__Sequence__fini(&msg->objects);
}

bool
sdsm_msgs__msg__SensorDataSharingMessage__are_equal(const sdsm_msgs__msg__SensorDataSharingMessage * lhs, const sdsm_msgs__msg__SensorDataSharingMessage * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // msg_cnt
  if (lhs->msg_cnt != rhs->msg_cnt) {
    return false;
  }
  // source_id
  for (size_t i = 0; i < 4; ++i) {
    if (lhs->source_id[i] != rhs->source_id[i]) {
      return false;
    }
  }
  // equipment_type
  if (lhs->equipment_type != rhs->equipment_type) {
    return false;
  }
  // sdsm_time_stamp
  if (!sdsm_msgs__msg__DDateTime__are_equal(
      &(lhs->sdsm_time_stamp), &(rhs->sdsm_time_stamp)))
  {
    return false;
  }
  // ref_pos
  if (!sdsm_msgs__msg__Position3D__are_equal(
      &(lhs->ref_pos), &(rhs->ref_pos)))
  {
    return false;
  }
  // objects
  if (!sdsm_msgs__msg__DetectedObjectData__Sequence__are_equal(
      &(lhs->objects), &(rhs->objects)))
  {
    return false;
  }
  return true;
}

bool
sdsm_msgs__msg__SensorDataSharingMessage__copy(
  const sdsm_msgs__msg__SensorDataSharingMessage * input,
  sdsm_msgs__msg__SensorDataSharingMessage * output)
{
  if (!input || !output) {
    return false;
  }
  // msg_cnt
  output->msg_cnt = input->msg_cnt;
  // source_id
  for (size_t i = 0; i < 4; ++i) {
    output->source_id[i] = input->source_id[i];
  }
  // equipment_type
  output->equipment_type = input->equipment_type;
  // sdsm_time_stamp
  if (!sdsm_msgs__msg__DDateTime__copy(
      &(input->sdsm_time_stamp), &(output->sdsm_time_stamp)))
  {
    return false;
  }
  // ref_pos
  if (!sdsm_msgs__msg__Position3D__copy(
      &(input->ref_pos), &(output->ref_pos)))
  {
    return false;
  }
  // objects
  if (!sdsm_msgs__msg__DetectedObjectData__Sequence__copy(
      &(input->objects), &(output->objects)))
  {
    return false;
  }
  return true;
}

sdsm_msgs__msg__SensorDataSharingMessage *
sdsm_msgs__msg__SensorDataSharingMessage__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__SensorDataSharingMessage * msg = (sdsm_msgs__msg__SensorDataSharingMessage *)allocator.allocate(sizeof(sdsm_msgs__msg__SensorDataSharingMessage), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sdsm_msgs__msg__SensorDataSharingMessage));
  bool success = sdsm_msgs__msg__SensorDataSharingMessage__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sdsm_msgs__msg__SensorDataSharingMessage__destroy(sdsm_msgs__msg__SensorDataSharingMessage * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sdsm_msgs__msg__SensorDataSharingMessage__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sdsm_msgs__msg__SensorDataSharingMessage__Sequence__init(sdsm_msgs__msg__SensorDataSharingMessage__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__SensorDataSharingMessage * data = NULL;

  if (size) {
    data = (sdsm_msgs__msg__SensorDataSharingMessage *)allocator.zero_allocate(size, sizeof(sdsm_msgs__msg__SensorDataSharingMessage), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sdsm_msgs__msg__SensorDataSharingMessage__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sdsm_msgs__msg__SensorDataSharingMessage__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sdsm_msgs__msg__SensorDataSharingMessage__Sequence__fini(sdsm_msgs__msg__SensorDataSharingMessage__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sdsm_msgs__msg__SensorDataSharingMessage__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sdsm_msgs__msg__SensorDataSharingMessage__Sequence *
sdsm_msgs__msg__SensorDataSharingMessage__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__SensorDataSharingMessage__Sequence * array = (sdsm_msgs__msg__SensorDataSharingMessage__Sequence *)allocator.allocate(sizeof(sdsm_msgs__msg__SensorDataSharingMessage__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sdsm_msgs__msg__SensorDataSharingMessage__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sdsm_msgs__msg__SensorDataSharingMessage__Sequence__destroy(sdsm_msgs__msg__SensorDataSharingMessage__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sdsm_msgs__msg__SensorDataSharingMessage__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sdsm_msgs__msg__SensorDataSharingMessage__Sequence__are_equal(const sdsm_msgs__msg__SensorDataSharingMessage__Sequence * lhs, const sdsm_msgs__msg__SensorDataSharingMessage__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sdsm_msgs__msg__SensorDataSharingMessage__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sdsm_msgs__msg__SensorDataSharingMessage__Sequence__copy(
  const sdsm_msgs__msg__SensorDataSharingMessage__Sequence * input,
  sdsm_msgs__msg__SensorDataSharingMessage__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sdsm_msgs__msg__SensorDataSharingMessage);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    sdsm_msgs__msg__SensorDataSharingMessage * data =
      (sdsm_msgs__msg__SensorDataSharingMessage *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sdsm_msgs__msg__SensorDataSharingMessage__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          sdsm_msgs__msg__SensorDataSharingMessage__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sdsm_msgs__msg__SensorDataSharingMessage__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
