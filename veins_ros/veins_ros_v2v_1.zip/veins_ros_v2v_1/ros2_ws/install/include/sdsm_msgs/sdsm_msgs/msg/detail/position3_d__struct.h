// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\Position3D.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position3_d.h"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION3_D__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__POSITION3_D__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/Position3D in the package sdsm_msgs.
/**
  * Reference position (J2735)
  * Sender's absolute geographic position; used as origin for object offsets
 */
typedef struct sdsm_msgs__msg__Position3D
{
  /// Latitude (1/10 microdegree units)
  /// Precision: 0.0000001 degrees (J2735 standard)
  int32_t lat;
  /// Longitude (1/10 microdegree units)
  /// Precision: 0.0000001 degrees (J2735 standard)
  int32_t lon;
  /// Elevation (10 cm units, -4096..61439, -4096=unknown)
  /// Height above sea level; -4096 indicates elevation not available
  int32_t elevation;
} sdsm_msgs__msg__Position3D;

// Struct for a sequence of sdsm_msgs__msg__Position3D.
typedef struct sdsm_msgs__msg__Position3D__Sequence
{
  sdsm_msgs__msg__Position3D * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__Position3D__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION3_D__STRUCT_H_
