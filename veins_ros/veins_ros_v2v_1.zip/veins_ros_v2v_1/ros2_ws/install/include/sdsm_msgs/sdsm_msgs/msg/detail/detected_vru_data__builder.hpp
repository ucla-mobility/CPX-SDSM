// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\DetectedVRUData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_vru_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/detected_vru_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_DetectedVRUData_basic_type
{
public:
  Init_DetectedVRUData_basic_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::sdsm_msgs::msg::DetectedVRUData basic_type(::sdsm_msgs::msg::DetectedVRUData::_basic_type_type arg)
  {
    msg_.basic_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVRUData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::DetectedVRUData>()
{
  return sdsm_msgs::msg::builder::Init_DetectedVRUData_basic_type();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__BUILDER_HPP_
