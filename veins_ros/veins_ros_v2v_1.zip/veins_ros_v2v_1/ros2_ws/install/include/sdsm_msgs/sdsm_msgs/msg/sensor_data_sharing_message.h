// generated from rosidl_generator_c/resource/idl.h.em
// with input from sdsm_msgs:msg\SensorDataSharingMessage.idl
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__SENSOR_DATA_SHARING_MESSAGE_H_
#define SDSM_MSGS__MSG__SENSOR_DATA_SHARING_MESSAGE_H_

#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__struct.h"
#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__functions.h"
#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__type_support.h"

#endif  // SDSM_MSGS__MSG__SENSOR_DATA_SHARING_MESSAGE_H_
