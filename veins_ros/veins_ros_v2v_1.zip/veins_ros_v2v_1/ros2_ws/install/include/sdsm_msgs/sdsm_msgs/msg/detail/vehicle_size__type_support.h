// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from sdsm_msgs:msg\VehicleSize.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/vehicle_size.h"


#ifndef SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__TYPE_SUPPORT_H_
#define SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "sdsm_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  sdsm_msgs,
  msg,
  VehicleSize
)(void);

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__TYPE_SUPPORT_H_
