// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\DetectedObjectCommonData.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/detected_object_common_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__DetectedObjectCommonData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x69, 0x6d, 0x59, 0xf7, 0xad, 0xe3, 0x2c, 0xdc,
      0xc6, 0x75, 0x30, 0xbe, 0xaa, 0x3e, 0xa2, 0x84,
      0x3d, 0xca, 0x0b, 0x3e, 0xb9, 0x26, 0x98, 0x6e,
      0x86, 0xed, 0xd4, 0x77, 0x6b, 0x79, 0x70, 0x2b,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "sdsm_msgs/msg/detail/position_offset_xyz__functions.h"
#include "sdsm_msgs/msg/detail/position_confidence_set__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t sdsm_msgs__msg__PositionConfidenceSet__EXPECTED_HASH = {1, {
    0xfc, 0x2c, 0x18, 0xaf, 0x56, 0x15, 0x84, 0xb6,
    0xd4, 0x95, 0xce, 0x73, 0x9c, 0x8d, 0x72, 0x38,
    0x77, 0x76, 0x95, 0xf5, 0xf3, 0xe2, 0x09, 0x5b,
    0xd2, 0x2f, 0x64, 0xfa, 0x6f, 0x57, 0x5c, 0x73,
  }};
static const rosidl_type_hash_t sdsm_msgs__msg__PositionOffsetXYZ__EXPECTED_HASH = {1, {
    0x21, 0x9d, 0x59, 0x90, 0x43, 0x5e, 0x11, 0x66,
    0x8c, 0x1d, 0x39, 0x31, 0x3d, 0xba, 0x9d, 0x4d,
    0xa5, 0x41, 0x17, 0xca, 0x03, 0x0e, 0xed, 0x94,
    0xd2, 0x33, 0x82, 0x75, 0x10, 0x57, 0x8b, 0xce,
  }};
#endif

static char sdsm_msgs__msg__DetectedObjectCommonData__TYPE_NAME[] = "sdsm_msgs/msg/DetectedObjectCommonData";
static char sdsm_msgs__msg__PositionConfidenceSet__TYPE_NAME[] = "sdsm_msgs/msg/PositionConfidenceSet";
static char sdsm_msgs__msg__PositionOffsetXYZ__TYPE_NAME[] = "sdsm_msgs/msg/PositionOffsetXYZ";

// Define type names, field names, and default values
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__obj_type[] = "obj_type";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__obj_type_cfd[] = "obj_type_cfd";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__object_id[] = "object_id";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__measurement_time[] = "measurement_time";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__pos[] = "pos";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__pos_confidence[] = "pos_confidence";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__speed[] = "speed";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__speed_z[] = "speed_z";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__has_speed_z[] = "has_speed_z";
static char sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__heading[] = "heading";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__DetectedObjectCommonData__FIELDS[] = {
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__obj_type, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__obj_type_cfd, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__object_id, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__measurement_time, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__pos, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {sdsm_msgs__msg__PositionOffsetXYZ__TYPE_NAME, 31, 31},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__pos_confidence, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {sdsm_msgs__msg__PositionConfidenceSet__TYPE_NAME, 35, 35},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__speed, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__speed_z, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__has_speed_z, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__FIELD_NAME__heading, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription sdsm_msgs__msg__DetectedObjectCommonData__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {sdsm_msgs__msg__PositionConfidenceSet__TYPE_NAME, 35, 35},
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__PositionOffsetXYZ__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__DetectedObjectCommonData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__DetectedObjectCommonData__TYPE_NAME, 38, 38},
      {sdsm_msgs__msg__DetectedObjectCommonData__FIELDS, 10, 10},
    },
    {sdsm_msgs__msg__DetectedObjectCommonData__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&sdsm_msgs__msg__PositionConfidenceSet__EXPECTED_HASH, sdsm_msgs__msg__PositionConfidenceSet__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = sdsm_msgs__msg__PositionConfidenceSet__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&sdsm_msgs__msg__PositionOffsetXYZ__EXPECTED_HASH, sdsm_msgs__msg__PositionOffsetXYZ__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = sdsm_msgs__msg__PositionOffsetXYZ__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Common data for detected object\n"
  "\n"
  "uint8 OBJ_TYPE_UNKNOWN = 0\n"
  "uint8 OBJ_TYPE_VEHICLE = 1\n"
  "uint8 OBJ_TYPE_VRU = 2\n"
  "uint8 OBJ_TYPE_ANIMAL = 3\n"
  "uint8 OBJ_TYPE_OBSTACLE = 4\n"
  "\n"
  "# Object type (use OBJ_TYPE_* constants)\n"
  "# High-level classification: vehicle, VRU, animal, or obstacle\n"
  "uint8 obj_type\n"
  "\n"
  "# Classification confidence (0=unknown, 1-100=confidence %, 101=unavailable)\n"
  "uint8 obj_type_cfd\n"
  "\n"
  "# Temporary object ID assigned by source\n"
  "# Unique within this message; used for tracking objects across multiple SDSM messages\n"
  "uint16 object_id\n"
  "\n"
  "# Measurement time offset from sDSMTimeStamp (ms, -1500..1500)\n"
  "# Relative to message timestamp; allows objects detected at different times\n"
  "# Negative = detected before message timestamp, positive = after\n"
  "int16 measurement_time\n"
  "\n"
  "# Position offset relative to sender's refPos\n"
  "# Uses relative coordinates for efficiency and coordinate system independence\n"
  "sdsm_msgs/PositionOffsetXYZ pos\n"
  "\n"
  "# Position confidence values (per J2735)\n"
  "# Indicates accuracy of position measurements\n"
  "sdsm_msgs/PositionConfidenceSet pos_confidence\n"
  "\n"
  "# Ground speed (0.02 m/s units, 8191=unavailable)\n"
  "uint16 speed\n"
  "\n"
  "# Z-axis speed (0.02 m/s units, 8191=unavailable)\n"
  "# Vertical velocity; optional because most objects move on ground plane\n"
  "uint16 speed_z\n"
  "bool has_speed_z\n"
  "\n"
  "# Heading (0.0125 deg units, 0-28799, 28800=unavailable)\n"
  "# Direction of travel in degrees (0-359.9875\\xc2\\xb0); 0.0125\\xc2\\xb0 precision per J2735\n"
  "uint16 heading";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__DetectedObjectCommonData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__DetectedObjectCommonData__TYPE_NAME, 38, 38},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 1416, 1416},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__DetectedObjectCommonData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__DetectedObjectCommonData__get_individual_type_description_source(NULL),
    sources[1] = *sdsm_msgs__msg__PositionConfidenceSet__get_individual_type_description_source(NULL);
    sources[2] = *sdsm_msgs__msg__PositionOffsetXYZ__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
