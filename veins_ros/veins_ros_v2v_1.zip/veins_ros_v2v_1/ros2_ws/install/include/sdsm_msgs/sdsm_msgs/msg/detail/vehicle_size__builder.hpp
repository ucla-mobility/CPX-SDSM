// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\VehicleSize.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/vehicle_size.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/vehicle_size__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_VehicleSize_length
{
public:
  explicit Init_VehicleSize_length(::sdsm_msgs::msg::VehicleSize & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::VehicleSize length(::sdsm_msgs::msg::VehicleSize::_length_type arg)
  {
    msg_.length = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::VehicleSize msg_;
};

class Init_VehicleSize_width
{
public:
  Init_VehicleSize_width()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VehicleSize_length width(::sdsm_msgs::msg::VehicleSize::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_VehicleSize_length(msg_);
  }

private:
  ::sdsm_msgs::msg::VehicleSize msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::VehicleSize>()
{
  return sdsm_msgs::msg::builder::Init_VehicleSize_width();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__BUILDER_HPP_
