// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\DetectedObstacleData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_obstacle_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'obst_size'
#include "sdsm_msgs/msg/detail/obstacle_size__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__DetectedObstacleData __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__DetectedObstacleData __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DetectedObstacleData_
{
  using Type = DetectedObstacleData_<ContainerAllocator>;

  explicit DetectedObstacleData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : obst_size(_init)
  {
    (void)_init;
  }

  explicit DetectedObstacleData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : obst_size(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _obst_size_type =
    sdsm_msgs::msg::ObstacleSize_<ContainerAllocator>;
  _obst_size_type obst_size;

  // setters for named parameter idiom
  Type & set__obst_size(
    const sdsm_msgs::msg::ObstacleSize_<ContainerAllocator> & _arg)
  {
    this->obst_size = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__DetectedObstacleData
    std::shared_ptr<sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__DetectedObstacleData
    std::shared_ptr<sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DetectedObstacleData_ & other) const
  {
    if (this->obst_size != other.obst_size) {
      return false;
    }
    return true;
  }
  bool operator!=(const DetectedObstacleData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DetectedObstacleData_

// alias to use template instance with default allocator
using DetectedObstacleData =
  sdsm_msgs::msg::DetectedObstacleData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__STRUCT_HPP_
