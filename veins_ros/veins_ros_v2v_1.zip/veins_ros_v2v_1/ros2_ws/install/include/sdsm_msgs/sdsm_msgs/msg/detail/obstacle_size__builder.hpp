// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\ObstacleSize.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/obstacle_size.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__OBSTACLE_SIZE__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__OBSTACLE_SIZE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/obstacle_size__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_ObstacleSize_height
{
public:
  explicit Init_ObstacleSize_height(::sdsm_msgs::msg::ObstacleSize & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::ObstacleSize height(::sdsm_msgs::msg::ObstacleSize::_height_type arg)
  {
    msg_.height = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::ObstacleSize msg_;
};

class Init_ObstacleSize_length
{
public:
  explicit Init_ObstacleSize_length(::sdsm_msgs::msg::ObstacleSize & msg)
  : msg_(msg)
  {}
  Init_ObstacleSize_height length(::sdsm_msgs::msg::ObstacleSize::_length_type arg)
  {
    msg_.length = std::move(arg);
    return Init_ObstacleSize_height(msg_);
  }

private:
  ::sdsm_msgs::msg::ObstacleSize msg_;
};

class Init_ObstacleSize_width
{
public:
  Init_ObstacleSize_width()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ObstacleSize_length width(::sdsm_msgs::msg::ObstacleSize::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_ObstacleSize_length(msg_);
  }

private:
  ::sdsm_msgs::msg::ObstacleSize msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::ObstacleSize>()
{
  return sdsm_msgs::msg::builder::Init_ObstacleSize_width();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__OBSTACLE_SIZE__BUILDER_HPP_
