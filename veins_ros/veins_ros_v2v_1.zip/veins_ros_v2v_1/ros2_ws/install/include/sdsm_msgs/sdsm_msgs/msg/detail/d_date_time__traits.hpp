// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sdsm_msgs:msg\DDateTime.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/d_date_time.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__TRAITS_HPP_
#define SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sdsm_msgs/msg/detail/d_date_time__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace sdsm_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DDateTime & msg,
  std::ostream & out)
{
  out << "{";
  // member: day_of_month
  {
    out << "day_of_month: ";
    rosidl_generator_traits::value_to_yaml(msg.day_of_month, out);
    out << ", ";
  }

  // member: time_of_day
  {
    out << "time_of_day: ";
    rosidl_generator_traits::value_to_yaml(msg.time_of_day, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DDateTime & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: day_of_month
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "day_of_month: ";
    rosidl_generator_traits::value_to_yaml(msg.day_of_month, out);
    out << "\n";
  }

  // member: time_of_day
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "time_of_day: ";
    rosidl_generator_traits::value_to_yaml(msg.time_of_day, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DDateTime & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sdsm_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sdsm_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sdsm_msgs::msg::DDateTime & msg,
  std::ostream & out, size_t indentation = 0)
{
  sdsm_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sdsm_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sdsm_msgs::msg::DDateTime & msg)
{
  return sdsm_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sdsm_msgs::msg::DDateTime>()
{
  return "sdsm_msgs::msg::DDateTime";
}

template<>
inline const char * name<sdsm_msgs::msg::DDateTime>()
{
  return "sdsm_msgs/msg/DDateTime";
}

template<>
struct has_fixed_size<sdsm_msgs::msg::DDateTime>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<sdsm_msgs::msg::DDateTime>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<sdsm_msgs::msg::DDateTime>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__TRAITS_HPP_
