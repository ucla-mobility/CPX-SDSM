// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\PositionConfidenceSet.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position_confidence_set.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/position_confidence_set__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_PositionConfidenceSet_elevation_confidence
{
public:
  explicit Init_PositionConfidenceSet_elevation_confidence(::sdsm_msgs::msg::PositionConfidenceSet & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::PositionConfidenceSet elevation_confidence(::sdsm_msgs::msg::PositionConfidenceSet::_elevation_confidence_type arg)
  {
    msg_.elevation_confidence = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::PositionConfidenceSet msg_;
};

class Init_PositionConfidenceSet_pos_confidence
{
public:
  Init_PositionConfidenceSet_pos_confidence()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PositionConfidenceSet_elevation_confidence pos_confidence(::sdsm_msgs::msg::PositionConfidenceSet::_pos_confidence_type arg)
  {
    msg_.pos_confidence = std::move(arg);
    return Init_PositionConfidenceSet_elevation_confidence(msg_);
  }

private:
  ::sdsm_msgs::msg::PositionConfidenceSet msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::PositionConfidenceSet>()
{
  return sdsm_msgs::msg::builder::Init_PositionConfidenceSet_pos_confidence();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__BUILDER_HPP_
