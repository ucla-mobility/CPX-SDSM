// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\DetectedObjectData.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/detected_object_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__DetectedObjectData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xaf, 0x9d, 0x9a, 0xd2, 0xdf, 0xe7, 0x39, 0x71,
      0xb9, 0xf5, 0x07, 0xda, 0x22, 0x0a, 0x53, 0xd8,
      0x52, 0xfb, 0x9c, 0x7a, 0x91, 0x12, 0xb8, 0xeb,
      0x5d, 0xcc, 0xb3, 0x66, 0xf6, 0x32, 0x88, 0x99,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "sdsm_msgs/msg/detail/obstacle_size__functions.h"
#include "sdsm_msgs/msg/detail/position_confidence_set__functions.h"
#include "sdsm_msgs/msg/detail/detected_vehicle_data__functions.h"
#include "sdsm_msgs/msg/detail/detected_object_common_data__functions.h"
#include "sdsm_msgs/msg/detail/detected_vru_data__functions.h"
#include "sdsm_msgs/msg/detail/position_offset_xyz__functions.h"
#include "sdsm_msgs/msg/detail/detected_obstacle_data__functions.h"
#include "sdsm_msgs/msg/detail/vehicle_size__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t sdsm_msgs__msg__DetectedObjectCommonData__EXPECTED_HASH = {1, {
    0x69, 0x6d, 0x59, 0xf7, 0xad, 0xe3, 0x2c, 0xdc,
    0xc6, 0x75, 0x30, 0xbe, 0xaa, 0x3e, 0xa2, 0x84,
    0x3d, 0xca, 0x0b, 0x3e, 0xb9, 0x26, 0x98, 0x6e,
    0x86, 0xed, 0xd4, 0x77, 0x6b, 0x79, 0x70, 0x2b,
  }};
static const rosidl_type_hash_t sdsm_msgs__msg__DetectedObstacleData__EXPECTED_HASH = {1, {
    0xf5, 0xea, 0x17, 0x83, 0xa0, 0x70, 0x98, 0x28,
    0xda, 0xe4, 0x24, 0xe1, 0x8e, 0x69, 0x1a, 0xaf,
    0xd6, 0x63, 0xbe, 0xb0, 0xec, 0xac, 0xb9, 0x31,
    0xfa, 0x0a, 0xe5, 0xfe, 0x82, 0xe4, 0xfb, 0x07,
  }};
static const rosidl_type_hash_t sdsm_msgs__msg__DetectedVRUData__EXPECTED_HASH = {1, {
    0x30, 0xce, 0xa8, 0xd0, 0x0d, 0x58, 0x5e, 0xd8,
    0xfc, 0xa5, 0x4b, 0xc7, 0x10, 0xaa, 0x37, 0x5b,
    0x38, 0xfa, 0x37, 0x92, 0x2c, 0x68, 0xc1, 0x36,
    0x7f, 0x16, 0x4c, 0x7b, 0x9c, 0x98, 0xc7, 0x65,
  }};
static const rosidl_type_hash_t sdsm_msgs__msg__DetectedVehicleData__EXPECTED_HASH = {1, {
    0x31, 0x22, 0x70, 0x9d, 0xc8, 0xcc, 0x6f, 0x1c,
    0x2a, 0x20, 0xf9, 0x62, 0xa5, 0x35, 0x09, 0xd0,
    0xa6, 0xb8, 0xf2, 0xc1, 0x68, 0x8f, 0xfd, 0x71,
    0x45, 0xcf, 0xf0, 0x44, 0x44, 0x2a, 0x21, 0x39,
  }};
static const rosidl_type_hash_t sdsm_msgs__msg__ObstacleSize__EXPECTED_HASH = {1, {
    0x24, 0x88, 0x38, 0xf2, 0x59, 0x79, 0xd2, 0x01,
    0xf6, 0x0a, 0x21, 0x46, 0x56, 0x0d, 0xe2, 0xdd,
    0xd3, 0x63, 0xf6, 0x5b, 0xe0, 0xb3, 0xa1, 0x75,
    0x75, 0xc4, 0x58, 0xaf, 0x2b, 0x11, 0x66, 0x19,
  }};
static const rosidl_type_hash_t sdsm_msgs__msg__PositionConfidenceSet__EXPECTED_HASH = {1, {
    0xfc, 0x2c, 0x18, 0xaf, 0x56, 0x15, 0x84, 0xb6,
    0xd4, 0x95, 0xce, 0x73, 0x9c, 0x8d, 0x72, 0x38,
    0x77, 0x76, 0x95, 0xf5, 0xf3, 0xe2, 0x09, 0x5b,
    0xd2, 0x2f, 0x64, 0xfa, 0x6f, 0x57, 0x5c, 0x73,
  }};
static const rosidl_type_hash_t sdsm_msgs__msg__PositionOffsetXYZ__EXPECTED_HASH = {1, {
    0x21, 0x9d, 0x59, 0x90, 0x43, 0x5e, 0x11, 0x66,
    0x8c, 0x1d, 0x39, 0x31, 0x3d, 0xba, 0x9d, 0x4d,
    0xa5, 0x41, 0x17, 0xca, 0x03, 0x0e, 0xed, 0x94,
    0xd2, 0x33, 0x82, 0x75, 0x10, 0x57, 0x8b, 0xce,
  }};
static const rosidl_type_hash_t sdsm_msgs__msg__VehicleSize__EXPECTED_HASH = {1, {
    0x3d, 0xeb, 0xe5, 0x1b, 0x9f, 0x33, 0x4c, 0xe3,
    0xbe, 0x5f, 0xf5, 0xed, 0x84, 0xc9, 0x1e, 0xfd,
    0x50, 0x76, 0xac, 0xcb, 0x5f, 0xbf, 0x60, 0x4a,
    0x3f, 0xfc, 0x20, 0x1b, 0x8c, 0x74, 0x51, 0x28,
  }};
#endif

static char sdsm_msgs__msg__DetectedObjectData__TYPE_NAME[] = "sdsm_msgs/msg/DetectedObjectData";
static char sdsm_msgs__msg__DetectedObjectCommonData__TYPE_NAME[] = "sdsm_msgs/msg/DetectedObjectCommonData";
static char sdsm_msgs__msg__DetectedObstacleData__TYPE_NAME[] = "sdsm_msgs/msg/DetectedObstacleData";
static char sdsm_msgs__msg__DetectedVRUData__TYPE_NAME[] = "sdsm_msgs/msg/DetectedVRUData";
static char sdsm_msgs__msg__DetectedVehicleData__TYPE_NAME[] = "sdsm_msgs/msg/DetectedVehicleData";
static char sdsm_msgs__msg__ObstacleSize__TYPE_NAME[] = "sdsm_msgs/msg/ObstacleSize";
static char sdsm_msgs__msg__PositionConfidenceSet__TYPE_NAME[] = "sdsm_msgs/msg/PositionConfidenceSet";
static char sdsm_msgs__msg__PositionOffsetXYZ__TYPE_NAME[] = "sdsm_msgs/msg/PositionOffsetXYZ";
static char sdsm_msgs__msg__VehicleSize__TYPE_NAME[] = "sdsm_msgs/msg/VehicleSize";

// Define type names, field names, and default values
static char sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_obj_common[] = "det_obj_common";
static char sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_obj_opt_kind[] = "det_obj_opt_kind";
static char sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_veh[] = "det_veh";
static char sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_vru[] = "det_vru";
static char sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_obst[] = "det_obst";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__DetectedObjectData__FIELDS[] = {
  {
    {sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_obj_common, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {sdsm_msgs__msg__DetectedObjectCommonData__TYPE_NAME, 38, 38},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_obj_opt_kind, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_veh, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {sdsm_msgs__msg__DetectedVehicleData__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_vru, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {sdsm_msgs__msg__DetectedVRUData__TYPE_NAME, 29, 29},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObjectData__FIELD_NAME__det_obst, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {sdsm_msgs__msg__DetectedObstacleData__TYPE_NAME, 34, 34},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription sdsm_msgs__msg__DetectedObjectData__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {sdsm_msgs__msg__DetectedObjectCommonData__TYPE_NAME, 38, 38},
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedObstacleData__TYPE_NAME, 34, 34},
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVRUData__TYPE_NAME, 29, 29},
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVehicleData__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__ObstacleSize__TYPE_NAME, 26, 26},
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__PositionConfidenceSet__TYPE_NAME, 35, 35},
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__PositionOffsetXYZ__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__VehicleSize__TYPE_NAME, 25, 25},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__DetectedObjectData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__DetectedObjectData__TYPE_NAME, 32, 32},
      {sdsm_msgs__msg__DetectedObjectData__FIELDS, 5, 5},
    },
    {sdsm_msgs__msg__DetectedObjectData__REFERENCED_TYPE_DESCRIPTIONS, 8, 8},
  };
  if (!constructed) {
    assert(0 == memcmp(&sdsm_msgs__msg__DetectedObjectCommonData__EXPECTED_HASH, sdsm_msgs__msg__DetectedObjectCommonData__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = sdsm_msgs__msg__DetectedObjectCommonData__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&sdsm_msgs__msg__DetectedObstacleData__EXPECTED_HASH, sdsm_msgs__msg__DetectedObstacleData__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = sdsm_msgs__msg__DetectedObstacleData__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&sdsm_msgs__msg__DetectedVRUData__EXPECTED_HASH, sdsm_msgs__msg__DetectedVRUData__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[2].fields = sdsm_msgs__msg__DetectedVRUData__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&sdsm_msgs__msg__DetectedVehicleData__EXPECTED_HASH, sdsm_msgs__msg__DetectedVehicleData__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[3].fields = sdsm_msgs__msg__DetectedVehicleData__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&sdsm_msgs__msg__ObstacleSize__EXPECTED_HASH, sdsm_msgs__msg__ObstacleSize__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[4].fields = sdsm_msgs__msg__ObstacleSize__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&sdsm_msgs__msg__PositionConfidenceSet__EXPECTED_HASH, sdsm_msgs__msg__PositionConfidenceSet__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[5].fields = sdsm_msgs__msg__PositionConfidenceSet__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&sdsm_msgs__msg__PositionOffsetXYZ__EXPECTED_HASH, sdsm_msgs__msg__PositionOffsetXYZ__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[6].fields = sdsm_msgs__msg__PositionOffsetXYZ__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&sdsm_msgs__msg__VehicleSize__EXPECTED_HASH, sdsm_msgs__msg__VehicleSize__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[7].fields = sdsm_msgs__msg__VehicleSize__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Detected object container\n"
  "\n"
  "uint8 OPT_DATA_NONE = 0\n"
  "uint8 OPT_DATA_VEHICLE = 1\n"
  "uint8 OPT_DATA_VRU = 2\n"
  "uint8 OPT_DATA_OBSTACLE = 3\n"
  "\n"
  "sdsm_msgs/DetectedObjectCommonData det_obj_common\n"
  "\n"
  "# CHOICE discriminator: only one of det_veh/det_vru/det_obst is valid\n"
  "# Check this field before reading type-specific data\n"
  "# 0=none, 1=vehicle, 2=VRU, 3=obstacle\n"
  "uint8 det_obj_opt_kind\n"
  "\n"
  "# Vehicle-specific data (valid only when det_obj_opt_kind == OPT_DATA_VEHICLE)\n"
  "sdsm_msgs/DetectedVehicleData det_veh\n"
  "\n"
  "# VRU-specific data (valid only when det_obj_opt_kind == OPT_DATA_VRU)\n"
  "sdsm_msgs/DetectedVRUData det_vru\n"
  "\n"
  "# Obstacle-specific data (valid only when det_obj_opt_kind == OPT_DATA_OBSTACLE)\n"
  "sdsm_msgs/DetectedObstacleData det_obst";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__DetectedObjectData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__DetectedObjectData__TYPE_NAME, 32, 32},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 714, 714},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__DetectedObjectData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[9];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 9, 9};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__DetectedObjectData__get_individual_type_description_source(NULL),
    sources[1] = *sdsm_msgs__msg__DetectedObjectCommonData__get_individual_type_description_source(NULL);
    sources[2] = *sdsm_msgs__msg__DetectedObstacleData__get_individual_type_description_source(NULL);
    sources[3] = *sdsm_msgs__msg__DetectedVRUData__get_individual_type_description_source(NULL);
    sources[4] = *sdsm_msgs__msg__DetectedVehicleData__get_individual_type_description_source(NULL);
    sources[5] = *sdsm_msgs__msg__ObstacleSize__get_individual_type_description_source(NULL);
    sources[6] = *sdsm_msgs__msg__PositionConfidenceSet__get_individual_type_description_source(NULL);
    sources[7] = *sdsm_msgs__msg__PositionOffsetXYZ__get_individual_type_description_source(NULL);
    sources[8] = *sdsm_msgs__msg__VehicleSize__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
