// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sdsm_msgs:msg\SensorDataSharingMessage.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/sensor_data_sharing_message.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__TRAITS_HPP_
#define SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'sdsm_time_stamp'
#include "sdsm_msgs/msg/detail/d_date_time__traits.hpp"
// Member 'ref_pos'
#include "sdsm_msgs/msg/detail/position3_d__traits.hpp"
// Member 'objects'
#include "sdsm_msgs/msg/detail/detected_object_data__traits.hpp"

namespace sdsm_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SensorDataSharingMessage & msg,
  std::ostream & out)
{
  out << "{";
  // member: msg_cnt
  {
    out << "msg_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.msg_cnt, out);
    out << ", ";
  }

  // member: source_id
  {
    if (msg.source_id.size() == 0) {
      out << "source_id: []";
    } else {
      out << "source_id: [";
      size_t pending_items = msg.source_id.size();
      for (auto item : msg.source_id) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: equipment_type
  {
    out << "equipment_type: ";
    rosidl_generator_traits::value_to_yaml(msg.equipment_type, out);
    out << ", ";
  }

  // member: sdsm_time_stamp
  {
    out << "sdsm_time_stamp: ";
    to_flow_style_yaml(msg.sdsm_time_stamp, out);
    out << ", ";
  }

  // member: ref_pos
  {
    out << "ref_pos: ";
    to_flow_style_yaml(msg.ref_pos, out);
    out << ", ";
  }

  // member: objects
  {
    if (msg.objects.size() == 0) {
      out << "objects: []";
    } else {
      out << "objects: [";
      size_t pending_items = msg.objects.size();
      for (auto item : msg.objects) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SensorDataSharingMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: msg_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "msg_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.msg_cnt, out);
    out << "\n";
  }

  // member: source_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.source_id.size() == 0) {
      out << "source_id: []\n";
    } else {
      out << "source_id:\n";
      for (auto item : msg.source_id) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: equipment_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "equipment_type: ";
    rosidl_generator_traits::value_to_yaml(msg.equipment_type, out);
    out << "\n";
  }

  // member: sdsm_time_stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sdsm_time_stamp:\n";
    to_block_style_yaml(msg.sdsm_time_stamp, out, indentation + 2);
  }

  // member: ref_pos
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ref_pos:\n";
    to_block_style_yaml(msg.ref_pos, out, indentation + 2);
  }

  // member: objects
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.objects.size() == 0) {
      out << "objects: []\n";
    } else {
      out << "objects:\n";
      for (auto item : msg.objects) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SensorDataSharingMessage & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sdsm_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sdsm_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sdsm_msgs::msg::SensorDataSharingMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  sdsm_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sdsm_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sdsm_msgs::msg::SensorDataSharingMessage & msg)
{
  return sdsm_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sdsm_msgs::msg::SensorDataSharingMessage>()
{
  return "sdsm_msgs::msg::SensorDataSharingMessage";
}

template<>
inline const char * name<sdsm_msgs::msg::SensorDataSharingMessage>()
{
  return "sdsm_msgs/msg/SensorDataSharingMessage";
}

template<>
struct has_fixed_size<sdsm_msgs::msg::SensorDataSharingMessage>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<sdsm_msgs::msg::SensorDataSharingMessage>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<sdsm_msgs::msg::SensorDataSharingMessage>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__TRAITS_HPP_
