// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\PositionOffsetXYZ.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position_offset_xyz.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/position_offset_xyz__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_PositionOffsetXYZ_has_offset_z
{
public:
  explicit Init_PositionOffsetXYZ_has_offset_z(::sdsm_msgs::msg::PositionOffsetXYZ & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::PositionOffsetXYZ has_offset_z(::sdsm_msgs::msg::PositionOffsetXYZ::_has_offset_z_type arg)
  {
    msg_.has_offset_z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::PositionOffsetXYZ msg_;
};

class Init_PositionOffsetXYZ_offset_z
{
public:
  explicit Init_PositionOffsetXYZ_offset_z(::sdsm_msgs::msg::PositionOffsetXYZ & msg)
  : msg_(msg)
  {}
  Init_PositionOffsetXYZ_has_offset_z offset_z(::sdsm_msgs::msg::PositionOffsetXYZ::_offset_z_type arg)
  {
    msg_.offset_z = std::move(arg);
    return Init_PositionOffsetXYZ_has_offset_z(msg_);
  }

private:
  ::sdsm_msgs::msg::PositionOffsetXYZ msg_;
};

class Init_PositionOffsetXYZ_offset_y
{
public:
  explicit Init_PositionOffsetXYZ_offset_y(::sdsm_msgs::msg::PositionOffsetXYZ & msg)
  : msg_(msg)
  {}
  Init_PositionOffsetXYZ_offset_z offset_y(::sdsm_msgs::msg::PositionOffsetXYZ::_offset_y_type arg)
  {
    msg_.offset_y = std::move(arg);
    return Init_PositionOffsetXYZ_offset_z(msg_);
  }

private:
  ::sdsm_msgs::msg::PositionOffsetXYZ msg_;
};

class Init_PositionOffsetXYZ_offset_x
{
public:
  Init_PositionOffsetXYZ_offset_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PositionOffsetXYZ_offset_y offset_x(::sdsm_msgs::msg::PositionOffsetXYZ::_offset_x_type arg)
  {
    msg_.offset_x = std::move(arg);
    return Init_PositionOffsetXYZ_offset_y(msg_);
  }

private:
  ::sdsm_msgs::msg::PositionOffsetXYZ msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::PositionOffsetXYZ>()
{
  return sdsm_msgs::msg::builder::Init_PositionOffsetXYZ_offset_x();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__BUILDER_HPP_
