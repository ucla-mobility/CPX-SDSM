// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\DetectedObjectCommonData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_object_common_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'pos'
#include "sdsm_msgs/msg/detail/position_offset_xyz__struct.hpp"
// Member 'pos_confidence'
#include "sdsm_msgs/msg/detail/position_confidence_set__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__DetectedObjectCommonData __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__DetectedObjectCommonData __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DetectedObjectCommonData_
{
  using Type = DetectedObjectCommonData_<ContainerAllocator>;

  explicit DetectedObjectCommonData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pos(_init),
    pos_confidence(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->obj_type = 0;
      this->obj_type_cfd = 0;
      this->object_id = 0;
      this->measurement_time = 0;
      this->speed = 0;
      this->speed_z = 0;
      this->has_speed_z = false;
      this->heading = 0;
    }
  }

  explicit DetectedObjectCommonData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pos(_alloc, _init),
    pos_confidence(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->obj_type = 0;
      this->obj_type_cfd = 0;
      this->object_id = 0;
      this->measurement_time = 0;
      this->speed = 0;
      this->speed_z = 0;
      this->has_speed_z = false;
      this->heading = 0;
    }
  }

  // field types and members
  using _obj_type_type =
    uint8_t;
  _obj_type_type obj_type;
  using _obj_type_cfd_type =
    uint8_t;
  _obj_type_cfd_type obj_type_cfd;
  using _object_id_type =
    uint16_t;
  _object_id_type object_id;
  using _measurement_time_type =
    int16_t;
  _measurement_time_type measurement_time;
  using _pos_type =
    sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator>;
  _pos_type pos;
  using _pos_confidence_type =
    sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator>;
  _pos_confidence_type pos_confidence;
  using _speed_type =
    uint16_t;
  _speed_type speed;
  using _speed_z_type =
    uint16_t;
  _speed_z_type speed_z;
  using _has_speed_z_type =
    bool;
  _has_speed_z_type has_speed_z;
  using _heading_type =
    uint16_t;
  _heading_type heading;

  // setters for named parameter idiom
  Type & set__obj_type(
    const uint8_t & _arg)
  {
    this->obj_type = _arg;
    return *this;
  }
  Type & set__obj_type_cfd(
    const uint8_t & _arg)
  {
    this->obj_type_cfd = _arg;
    return *this;
  }
  Type & set__object_id(
    const uint16_t & _arg)
  {
    this->object_id = _arg;
    return *this;
  }
  Type & set__measurement_time(
    const int16_t & _arg)
  {
    this->measurement_time = _arg;
    return *this;
  }
  Type & set__pos(
    const sdsm_msgs::msg::PositionOffsetXYZ_<ContainerAllocator> & _arg)
  {
    this->pos = _arg;
    return *this;
  }
  Type & set__pos_confidence(
    const sdsm_msgs::msg::PositionConfidenceSet_<ContainerAllocator> & _arg)
  {
    this->pos_confidence = _arg;
    return *this;
  }
  Type & set__speed(
    const uint16_t & _arg)
  {
    this->speed = _arg;
    return *this;
  }
  Type & set__speed_z(
    const uint16_t & _arg)
  {
    this->speed_z = _arg;
    return *this;
  }
  Type & set__has_speed_z(
    const bool & _arg)
  {
    this->has_speed_z = _arg;
    return *this;
  }
  Type & set__heading(
    const uint16_t & _arg)
  {
    this->heading = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t OBJ_TYPE_UNKNOWN =
    0u;
  static constexpr uint8_t OBJ_TYPE_VEHICLE =
    1u;
  static constexpr uint8_t OBJ_TYPE_VRU =
    2u;
  static constexpr uint8_t OBJ_TYPE_ANIMAL =
    3u;
  static constexpr uint8_t OBJ_TYPE_OBSTACLE =
    4u;

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__DetectedObjectCommonData
    std::shared_ptr<sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__DetectedObjectCommonData
    std::shared_ptr<sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DetectedObjectCommonData_ & other) const
  {
    if (this->obj_type != other.obj_type) {
      return false;
    }
    if (this->obj_type_cfd != other.obj_type_cfd) {
      return false;
    }
    if (this->object_id != other.object_id) {
      return false;
    }
    if (this->measurement_time != other.measurement_time) {
      return false;
    }
    if (this->pos != other.pos) {
      return false;
    }
    if (this->pos_confidence != other.pos_confidence) {
      return false;
    }
    if (this->speed != other.speed) {
      return false;
    }
    if (this->speed_z != other.speed_z) {
      return false;
    }
    if (this->has_speed_z != other.has_speed_z) {
      return false;
    }
    if (this->heading != other.heading) {
      return false;
    }
    return true;
  }
  bool operator!=(const DetectedObjectCommonData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DetectedObjectCommonData_

// alias to use template instance with default allocator
using DetectedObjectCommonData =
  sdsm_msgs::msg::DetectedObjectCommonData_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectCommonData_<ContainerAllocator>::OBJ_TYPE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectCommonData_<ContainerAllocator>::OBJ_TYPE_VEHICLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectCommonData_<ContainerAllocator>::OBJ_TYPE_VRU;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectCommonData_<ContainerAllocator>::OBJ_TYPE_ANIMAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectCommonData_<ContainerAllocator>::OBJ_TYPE_OBSTACLE;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__STRUCT_HPP_
