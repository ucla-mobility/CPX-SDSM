// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__VEHICLE_SIZE_HPP_
#define SDSM_MSGS__MSG__VEHICLE_SIZE_HPP_

#include "sdsm_msgs/msg/detail/vehicle_size__struct.hpp"
#include "sdsm_msgs/msg/detail/vehicle_size__builder.hpp"
#include "sdsm_msgs/msg/detail/vehicle_size__traits.hpp"
#include "sdsm_msgs/msg/detail/vehicle_size__type_support.hpp"

#endif  // SDSM_MSGS__MSG__VEHICLE_SIZE_HPP_
