// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\DetectedVehicleData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_vehicle_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_VEHICLE_DATA__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_VEHICLE_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/detected_vehicle_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_DetectedVehicleData_has_class_conf
{
public:
  explicit Init_DetectedVehicleData_has_class_conf(::sdsm_msgs::msg::DetectedVehicleData & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::DetectedVehicleData has_class_conf(::sdsm_msgs::msg::DetectedVehicleData::_has_class_conf_type arg)
  {
    msg_.has_class_conf = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVehicleData msg_;
};

class Init_DetectedVehicleData_class_conf
{
public:
  explicit Init_DetectedVehicleData_class_conf(::sdsm_msgs::msg::DetectedVehicleData & msg)
  : msg_(msg)
  {}
  Init_DetectedVehicleData_has_class_conf class_conf(::sdsm_msgs::msg::DetectedVehicleData::_class_conf_type arg)
  {
    msg_.class_conf = std::move(arg);
    return Init_DetectedVehicleData_has_class_conf(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVehicleData msg_;
};

class Init_DetectedVehicleData_has_vehicle_class
{
public:
  explicit Init_DetectedVehicleData_has_vehicle_class(::sdsm_msgs::msg::DetectedVehicleData & msg)
  : msg_(msg)
  {}
  Init_DetectedVehicleData_class_conf has_vehicle_class(::sdsm_msgs::msg::DetectedVehicleData::_has_vehicle_class_type arg)
  {
    msg_.has_vehicle_class = std::move(arg);
    return Init_DetectedVehicleData_class_conf(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVehicleData msg_;
};

class Init_DetectedVehicleData_vehicle_class
{
public:
  explicit Init_DetectedVehicleData_vehicle_class(::sdsm_msgs::msg::DetectedVehicleData & msg)
  : msg_(msg)
  {}
  Init_DetectedVehicleData_has_vehicle_class vehicle_class(::sdsm_msgs::msg::DetectedVehicleData::_vehicle_class_type arg)
  {
    msg_.vehicle_class = std::move(arg);
    return Init_DetectedVehicleData_has_vehicle_class(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVehicleData msg_;
};

class Init_DetectedVehicleData_has_height
{
public:
  explicit Init_DetectedVehicleData_has_height(::sdsm_msgs::msg::DetectedVehicleData & msg)
  : msg_(msg)
  {}
  Init_DetectedVehicleData_vehicle_class has_height(::sdsm_msgs::msg::DetectedVehicleData::_has_height_type arg)
  {
    msg_.has_height = std::move(arg);
    return Init_DetectedVehicleData_vehicle_class(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVehicleData msg_;
};

class Init_DetectedVehicleData_height
{
public:
  explicit Init_DetectedVehicleData_height(::sdsm_msgs::msg::DetectedVehicleData & msg)
  : msg_(msg)
  {}
  Init_DetectedVehicleData_has_height height(::sdsm_msgs::msg::DetectedVehicleData::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_DetectedVehicleData_has_height(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVehicleData msg_;
};

class Init_DetectedVehicleData_has_size
{
public:
  explicit Init_DetectedVehicleData_has_size(::sdsm_msgs::msg::DetectedVehicleData & msg)
  : msg_(msg)
  {}
  Init_DetectedVehicleData_height has_size(::sdsm_msgs::msg::DetectedVehicleData::_has_size_type arg)
  {
    msg_.has_size = std::move(arg);
    return Init_DetectedVehicleData_height(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVehicleData msg_;
};

class Init_DetectedVehicleData_size
{
public:
  Init_DetectedVehicleData_size()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DetectedVehicleData_has_size size(::sdsm_msgs::msg::DetectedVehicleData::_size_type arg)
  {
    msg_.size = std::move(arg);
    return Init_DetectedVehicleData_has_size(msg_);
  }

private:
  ::sdsm_msgs::msg::DetectedVehicleData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::DetectedVehicleData>()
{
  return sdsm_msgs::msg::builder::Init_DetectedVehicleData_size();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_VEHICLE_DATA__BUILDER_HPP_
