// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__POSITION3_D_HPP_
#define SDSM_MSGS__MSG__POSITION3_D_HPP_

#include "sdsm_msgs/msg/detail/position3_d__struct.hpp"
#include "sdsm_msgs/msg/detail/position3_d__builder.hpp"
#include "sdsm_msgs/msg/detail/position3_d__traits.hpp"
#include "sdsm_msgs/msg/detail/position3_d__type_support.hpp"

#endif  // SDSM_MSGS__MSG__POSITION3_D_HPP_
