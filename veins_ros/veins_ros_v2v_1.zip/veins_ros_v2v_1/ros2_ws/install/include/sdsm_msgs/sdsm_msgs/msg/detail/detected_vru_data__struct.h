// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\DetectedVRUData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_vru_data.h"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'VRU_TYPE_UNAVAILABLE'.
enum
{
  sdsm_msgs__msg__DetectedVRUData__VRU_TYPE_UNAVAILABLE = 0
};

/// Constant 'VRU_TYPE_PEDESTRIAN'.
enum
{
  sdsm_msgs__msg__DetectedVRUData__VRU_TYPE_PEDESTRIAN = 1
};

/// Constant 'VRU_TYPE_PEDALCYCLIST'.
enum
{
  sdsm_msgs__msg__DetectedVRUData__VRU_TYPE_PEDALCYCLIST = 2
};

/// Constant 'VRU_TYPE_PUBLIC_SAFETY_WORKER'.
enum
{
  sdsm_msgs__msg__DetectedVRUData__VRU_TYPE_PUBLIC_SAFETY_WORKER = 3
};

/// Constant 'VRU_TYPE_ANIMAL'.
enum
{
  sdsm_msgs__msg__DetectedVRUData__VRU_TYPE_ANIMAL = 4
};

/// Struct defined in msg/DetectedVRUData in the package sdsm_msgs.
/**
  * VRU (Vulnerable Road User) specific data
 */
typedef struct sdsm_msgs__msg__DetectedVRUData
{
  /// VRU basic type (use VRU_TYPE_* constants)
  /// Classifies vulnerable road user: pedestrian, cyclist, worker, or animal
  uint8_t basic_type;
} sdsm_msgs__msg__DetectedVRUData;

// Struct for a sequence of sdsm_msgs__msg__DetectedVRUData.
typedef struct sdsm_msgs__msg__DetectedVRUData__Sequence
{
  sdsm_msgs__msg__DetectedVRUData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__DetectedVRUData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__STRUCT_H_
