// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\Position3D.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position3_d.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION3_D__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__POSITION3_D__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__Position3D __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__Position3D __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Position3D_
{
  using Type = Position3D_<ContainerAllocator>;

  explicit Position3D_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->lat = 0l;
      this->lon = 0l;
      this->elevation = 0l;
    }
  }

  explicit Position3D_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->lat = 0l;
      this->lon = 0l;
      this->elevation = 0l;
    }
  }

  // field types and members
  using _lat_type =
    int32_t;
  _lat_type lat;
  using _lon_type =
    int32_t;
  _lon_type lon;
  using _elevation_type =
    int32_t;
  _elevation_type elevation;

  // setters for named parameter idiom
  Type & set__lat(
    const int32_t & _arg)
  {
    this->lat = _arg;
    return *this;
  }
  Type & set__lon(
    const int32_t & _arg)
  {
    this->lon = _arg;
    return *this;
  }
  Type & set__elevation(
    const int32_t & _arg)
  {
    this->elevation = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::Position3D_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::Position3D_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::Position3D_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::Position3D_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::Position3D_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::Position3D_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::Position3D_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::Position3D_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::Position3D_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::Position3D_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__Position3D
    std::shared_ptr<sdsm_msgs::msg::Position3D_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__Position3D
    std::shared_ptr<sdsm_msgs::msg::Position3D_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Position3D_ & other) const
  {
    if (this->lat != other.lat) {
      return false;
    }
    if (this->lon != other.lon) {
      return false;
    }
    if (this->elevation != other.elevation) {
      return false;
    }
    return true;
  }
  bool operator!=(const Position3D_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Position3D_

// alias to use template instance with default allocator
using Position3D =
  sdsm_msgs::msg::Position3D_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION3_D__STRUCT_HPP_
