// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sdsm_msgs:msg\ObstacleSize.idl
// generated code does not contain a copyright notice
#include "sdsm_msgs/msg/detail/obstacle_size__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
sdsm_msgs__msg__ObstacleSize__init(sdsm_msgs__msg__ObstacleSize * msg)
{
  if (!msg) {
    return false;
  }
  // width
  // length
  // height
  return true;
}

void
sdsm_msgs__msg__ObstacleSize__fini(sdsm_msgs__msg__ObstacleSize * msg)
{
  if (!msg) {
    return;
  }
  // width
  // length
  // height
}

bool
sdsm_msgs__msg__ObstacleSize__are_equal(const sdsm_msgs__msg__ObstacleSize * lhs, const sdsm_msgs__msg__ObstacleSize * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // width
  if (lhs->width != rhs->width) {
    return false;
  }
  // length
  if (lhs->length != rhs->length) {
    return false;
  }
  // height
  if (lhs->height != rhs->height) {
    return false;
  }
  return true;
}

bool
sdsm_msgs__msg__ObstacleSize__copy(
  const sdsm_msgs__msg__ObstacleSize * input,
  sdsm_msgs__msg__ObstacleSize * output)
{
  if (!input || !output) {
    return false;
  }
  // width
  output->width = input->width;
  // length
  output->length = input->length;
  // height
  output->height = input->height;
  return true;
}

sdsm_msgs__msg__ObstacleSize *
sdsm_msgs__msg__ObstacleSize__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__ObstacleSize * msg = (sdsm_msgs__msg__ObstacleSize *)allocator.allocate(sizeof(sdsm_msgs__msg__ObstacleSize), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sdsm_msgs__msg__ObstacleSize));
  bool success = sdsm_msgs__msg__ObstacleSize__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sdsm_msgs__msg__ObstacleSize__destroy(sdsm_msgs__msg__ObstacleSize * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sdsm_msgs__msg__ObstacleSize__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sdsm_msgs__msg__ObstacleSize__Sequence__init(sdsm_msgs__msg__ObstacleSize__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__ObstacleSize * data = NULL;

  if (size) {
    data = (sdsm_msgs__msg__ObstacleSize *)allocator.zero_allocate(size, sizeof(sdsm_msgs__msg__ObstacleSize), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sdsm_msgs__msg__ObstacleSize__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sdsm_msgs__msg__ObstacleSize__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sdsm_msgs__msg__ObstacleSize__Sequence__fini(sdsm_msgs__msg__ObstacleSize__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sdsm_msgs__msg__ObstacleSize__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sdsm_msgs__msg__ObstacleSize__Sequence *
sdsm_msgs__msg__ObstacleSize__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__ObstacleSize__Sequence * array = (sdsm_msgs__msg__ObstacleSize__Sequence *)allocator.allocate(sizeof(sdsm_msgs__msg__ObstacleSize__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sdsm_msgs__msg__ObstacleSize__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sdsm_msgs__msg__ObstacleSize__Sequence__destroy(sdsm_msgs__msg__ObstacleSize__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sdsm_msgs__msg__ObstacleSize__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sdsm_msgs__msg__ObstacleSize__Sequence__are_equal(const sdsm_msgs__msg__ObstacleSize__Sequence * lhs, const sdsm_msgs__msg__ObstacleSize__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sdsm_msgs__msg__ObstacleSize__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sdsm_msgs__msg__ObstacleSize__Sequence__copy(
  const sdsm_msgs__msg__ObstacleSize__Sequence * input,
  sdsm_msgs__msg__ObstacleSize__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sdsm_msgs__msg__ObstacleSize);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    sdsm_msgs__msg__ObstacleSize * data =
      (sdsm_msgs__msg__ObstacleSize *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sdsm_msgs__msg__ObstacleSize__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          sdsm_msgs__msg__ObstacleSize__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sdsm_msgs__msg__ObstacleSize__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
