// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sdsm_msgs:msg\DetectedObstacleData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_obstacle_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__TRAITS_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sdsm_msgs/msg/detail/detected_obstacle_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'obst_size'
#include "sdsm_msgs/msg/detail/obstacle_size__traits.hpp"

namespace sdsm_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DetectedObstacleData & msg,
  std::ostream & out)
{
  out << "{";
  // member: obst_size
  {
    out << "obst_size: ";
    to_flow_style_yaml(msg.obst_size, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DetectedObstacleData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: obst_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obst_size:\n";
    to_block_style_yaml(msg.obst_size, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DetectedObstacleData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sdsm_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sdsm_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sdsm_msgs::msg::DetectedObstacleData & msg,
  std::ostream & out, size_t indentation = 0)
{
  sdsm_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sdsm_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sdsm_msgs::msg::DetectedObstacleData & msg)
{
  return sdsm_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sdsm_msgs::msg::DetectedObstacleData>()
{
  return "sdsm_msgs::msg::DetectedObstacleData";
}

template<>
inline const char * name<sdsm_msgs::msg::DetectedObstacleData>()
{
  return "sdsm_msgs/msg/DetectedObstacleData";
}

template<>
struct has_fixed_size<sdsm_msgs::msg::DetectedObstacleData>
  : std::integral_constant<bool, has_fixed_size<sdsm_msgs::msg::ObstacleSize>::value> {};

template<>
struct has_bounded_size<sdsm_msgs::msg::DetectedObstacleData>
  : std::integral_constant<bool, has_bounded_size<sdsm_msgs::msg::ObstacleSize>::value> {};

template<>
struct is_message<sdsm_msgs::msg::DetectedObstacleData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBSTACLE_DATA__TRAITS_HPP_
