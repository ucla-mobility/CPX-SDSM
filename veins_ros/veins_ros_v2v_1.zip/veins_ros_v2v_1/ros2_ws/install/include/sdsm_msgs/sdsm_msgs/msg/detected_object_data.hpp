// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__DETECTED_OBJECT_DATA_HPP_
#define SDSM_MSGS__MSG__DETECTED_OBJECT_DATA_HPP_

#include "sdsm_msgs/msg/detail/detected_object_data__struct.hpp"
#include "sdsm_msgs/msg/detail/detected_object_data__builder.hpp"
#include "sdsm_msgs/msg/detail/detected_object_data__traits.hpp"
#include "sdsm_msgs/msg/detail/detected_object_data__type_support.hpp"

#endif  // SDSM_MSGS__MSG__DETECTED_OBJECT_DATA_HPP_
