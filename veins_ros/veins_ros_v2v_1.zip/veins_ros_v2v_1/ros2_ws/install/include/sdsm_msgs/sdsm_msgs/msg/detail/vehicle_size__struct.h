// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\VehicleSize.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/vehicle_size.h"


#ifndef SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/VehicleSize in the package sdsm_msgs.
/**
  * Vehicle dimensions (J2735)
  * Width and length in centimeters per J2735 VehicleSize specification
 */
typedef struct sdsm_msgs__msg__VehicleSize
{
  /// cm, 0-1023, 0=unavailable
  uint16_t width;
  /// cm, 0-4095, 0=unavailable
  uint16_t length;
} sdsm_msgs__msg__VehicleSize;

// Struct for a sequence of sdsm_msgs__msg__VehicleSize.
typedef struct sdsm_msgs__msg__VehicleSize__Sequence
{
  sdsm_msgs__msg__VehicleSize * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__VehicleSize__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__VEHICLE_SIZE__STRUCT_H_
