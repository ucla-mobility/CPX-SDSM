// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sdsm_msgs:msg\DetectedObjectCommonData.idl
// generated code does not contain a copyright notice
#include "sdsm_msgs/msg/detail/detected_object_common_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `pos`
#include "sdsm_msgs/msg/detail/position_offset_xyz__functions.h"
// Member `pos_confidence`
#include "sdsm_msgs/msg/detail/position_confidence_set__functions.h"

bool
sdsm_msgs__msg__DetectedObjectCommonData__init(sdsm_msgs__msg__DetectedObjectCommonData * msg)
{
  if (!msg) {
    return false;
  }
  // obj_type
  // obj_type_cfd
  // object_id
  // measurement_time
  // pos
  if (!sdsm_msgs__msg__PositionOffsetXYZ__init(&msg->pos)) {
    sdsm_msgs__msg__DetectedObjectCommonData__fini(msg);
    return false;
  }
  // pos_confidence
  if (!sdsm_msgs__msg__PositionConfidenceSet__init(&msg->pos_confidence)) {
    sdsm_msgs__msg__DetectedObjectCommonData__fini(msg);
    return false;
  }
  // speed
  // speed_z
  // has_speed_z
  // heading
  return true;
}

void
sdsm_msgs__msg__DetectedObjectCommonData__fini(sdsm_msgs__msg__DetectedObjectCommonData * msg)
{
  if (!msg) {
    return;
  }
  // obj_type
  // obj_type_cfd
  // object_id
  // measurement_time
  // pos
  sdsm_msgs__msg__PositionOffsetXYZ__fini(&msg->pos);
  // pos_confidence
  sdsm_msgs__msg__PositionConfidenceSet__fini(&msg->pos_confidence);
  // speed
  // speed_z
  // has_speed_z
  // heading
}

bool
sdsm_msgs__msg__DetectedObjectCommonData__are_equal(const sdsm_msgs__msg__DetectedObjectCommonData * lhs, const sdsm_msgs__msg__DetectedObjectCommonData * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // obj_type
  if (lhs->obj_type != rhs->obj_type) {
    return false;
  }
  // obj_type_cfd
  if (lhs->obj_type_cfd != rhs->obj_type_cfd) {
    return false;
  }
  // object_id
  if (lhs->object_id != rhs->object_id) {
    return false;
  }
  // measurement_time
  if (lhs->measurement_time != rhs->measurement_time) {
    return false;
  }
  // pos
  if (!sdsm_msgs__msg__PositionOffsetXYZ__are_equal(
      &(lhs->pos), &(rhs->pos)))
  {
    return false;
  }
  // pos_confidence
  if (!sdsm_msgs__msg__PositionConfidenceSet__are_equal(
      &(lhs->pos_confidence), &(rhs->pos_confidence)))
  {
    return false;
  }
  // speed
  if (lhs->speed != rhs->speed) {
    return false;
  }
  // speed_z
  if (lhs->speed_z != rhs->speed_z) {
    return false;
  }
  // has_speed_z
  if (lhs->has_speed_z != rhs->has_speed_z) {
    return false;
  }
  // heading
  if (lhs->heading != rhs->heading) {
    return false;
  }
  return true;
}

bool
sdsm_msgs__msg__DetectedObjectCommonData__copy(
  const sdsm_msgs__msg__DetectedObjectCommonData * input,
  sdsm_msgs__msg__DetectedObjectCommonData * output)
{
  if (!input || !output) {
    return false;
  }
  // obj_type
  output->obj_type = input->obj_type;
  // obj_type_cfd
  output->obj_type_cfd = input->obj_type_cfd;
  // object_id
  output->object_id = input->object_id;
  // measurement_time
  output->measurement_time = input->measurement_time;
  // pos
  if (!sdsm_msgs__msg__PositionOffsetXYZ__copy(
      &(input->pos), &(output->pos)))
  {
    return false;
  }
  // pos_confidence
  if (!sdsm_msgs__msg__PositionConfidenceSet__copy(
      &(input->pos_confidence), &(output->pos_confidence)))
  {
    return false;
  }
  // speed
  output->speed = input->speed;
  // speed_z
  output->speed_z = input->speed_z;
  // has_speed_z
  output->has_speed_z = input->has_speed_z;
  // heading
  output->heading = input->heading;
  return true;
}

sdsm_msgs__msg__DetectedObjectCommonData *
sdsm_msgs__msg__DetectedObjectCommonData__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__DetectedObjectCommonData * msg = (sdsm_msgs__msg__DetectedObjectCommonData *)allocator.allocate(sizeof(sdsm_msgs__msg__DetectedObjectCommonData), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sdsm_msgs__msg__DetectedObjectCommonData));
  bool success = sdsm_msgs__msg__DetectedObjectCommonData__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sdsm_msgs__msg__DetectedObjectCommonData__destroy(sdsm_msgs__msg__DetectedObjectCommonData * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sdsm_msgs__msg__DetectedObjectCommonData__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sdsm_msgs__msg__DetectedObjectCommonData__Sequence__init(sdsm_msgs__msg__DetectedObjectCommonData__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__DetectedObjectCommonData * data = NULL;

  if (size) {
    data = (sdsm_msgs__msg__DetectedObjectCommonData *)allocator.zero_allocate(size, sizeof(sdsm_msgs__msg__DetectedObjectCommonData), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sdsm_msgs__msg__DetectedObjectCommonData__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sdsm_msgs__msg__DetectedObjectCommonData__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sdsm_msgs__msg__DetectedObjectCommonData__Sequence__fini(sdsm_msgs__msg__DetectedObjectCommonData__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sdsm_msgs__msg__DetectedObjectCommonData__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sdsm_msgs__msg__DetectedObjectCommonData__Sequence *
sdsm_msgs__msg__DetectedObjectCommonData__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__DetectedObjectCommonData__Sequence * array = (sdsm_msgs__msg__DetectedObjectCommonData__Sequence *)allocator.allocate(sizeof(sdsm_msgs__msg__DetectedObjectCommonData__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sdsm_msgs__msg__DetectedObjectCommonData__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sdsm_msgs__msg__DetectedObjectCommonData__Sequence__destroy(sdsm_msgs__msg__DetectedObjectCommonData__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sdsm_msgs__msg__DetectedObjectCommonData__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sdsm_msgs__msg__DetectedObjectCommonData__Sequence__are_equal(const sdsm_msgs__msg__DetectedObjectCommonData__Sequence * lhs, const sdsm_msgs__msg__DetectedObjectCommonData__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sdsm_msgs__msg__DetectedObjectCommonData__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sdsm_msgs__msg__DetectedObjectCommonData__Sequence__copy(
  const sdsm_msgs__msg__DetectedObjectCommonData__Sequence * input,
  sdsm_msgs__msg__DetectedObjectCommonData__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sdsm_msgs__msg__DetectedObjectCommonData);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    sdsm_msgs__msg__DetectedObjectCommonData * data =
      (sdsm_msgs__msg__DetectedObjectCommonData *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sdsm_msgs__msg__DetectedObjectCommonData__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          sdsm_msgs__msg__DetectedObjectCommonData__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sdsm_msgs__msg__DetectedObjectCommonData__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
