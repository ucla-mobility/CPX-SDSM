// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from sdsm_msgs:msg\ObstacleSize.idl
// generated code does not contain a copyright notice
#ifndef SDSM_MSGS__MSG__DETAIL__OBSTACLE_SIZE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define SDSM_MSGS__MSG__DETAIL__OBSTACLE_SIZE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "sdsm_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "sdsm_msgs/msg/detail/obstacle_size__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sdsm_msgs
bool cdr_serialize_sdsm_msgs__msg__ObstacleSize(
  const sdsm_msgs__msg__ObstacleSize * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sdsm_msgs
bool cdr_deserialize_sdsm_msgs__msg__ObstacleSize(
  eprosima::fastcdr::Cdr &,
  sdsm_msgs__msg__ObstacleSize * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sdsm_msgs
size_t get_serialized_size_sdsm_msgs__msg__ObstacleSize(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sdsm_msgs
size_t max_serialized_size_sdsm_msgs__msg__ObstacleSize(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sdsm_msgs
bool cdr_serialize_key_sdsm_msgs__msg__ObstacleSize(
  const sdsm_msgs__msg__ObstacleSize * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sdsm_msgs
size_t get_serialized_size_key_sdsm_msgs__msg__ObstacleSize(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sdsm_msgs
size_t max_serialized_size_key_sdsm_msgs__msg__ObstacleSize(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sdsm_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, sdsm_msgs, msg, ObstacleSize)();

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__OBSTACLE_SIZE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
