// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\VehicleSize.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/vehicle_size__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__VehicleSize__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x3d, 0xeb, 0xe5, 0x1b, 0x9f, 0x33, 0x4c, 0xe3,
      0xbe, 0x5f, 0xf5, 0xed, 0x84, 0xc9, 0x1e, 0xfd,
      0x50, 0x76, 0xac, 0xcb, 0x5f, 0xbf, 0x60, 0x4a,
      0x3f, 0xfc, 0x20, 0x1b, 0x8c, 0x74, 0x51, 0x28,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char sdsm_msgs__msg__VehicleSize__TYPE_NAME[] = "sdsm_msgs/msg/VehicleSize";

// Define type names, field names, and default values
static char sdsm_msgs__msg__VehicleSize__FIELD_NAME__width[] = "width";
static char sdsm_msgs__msg__VehicleSize__FIELD_NAME__length[] = "length";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__VehicleSize__FIELDS[] = {
  {
    {sdsm_msgs__msg__VehicleSize__FIELD_NAME__width, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__VehicleSize__FIELD_NAME__length, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__VehicleSize__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__VehicleSize__TYPE_NAME, 25, 25},
      {sdsm_msgs__msg__VehicleSize__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Vehicle dimensions (J2735)\n"
  "# Width and length in centimeters per J2735 VehicleSize specification\n"
  "\n"
  "uint16 width  # cm, 0-1023, 0=unavailable\n"
  "uint16 length  # cm, 0-4095, 0=unavailable";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__VehicleSize__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__VehicleSize__TYPE_NAME, 25, 25},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 185, 185},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__VehicleSize__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__VehicleSize__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
