// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\DetectedObjectData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_object_data.h"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'OPT_DATA_NONE'.
enum
{
  sdsm_msgs__msg__DetectedObjectData__OPT_DATA_NONE = 0
};

/// Constant 'OPT_DATA_VEHICLE'.
enum
{
  sdsm_msgs__msg__DetectedObjectData__OPT_DATA_VEHICLE = 1
};

/// Constant 'OPT_DATA_VRU'.
enum
{
  sdsm_msgs__msg__DetectedObjectData__OPT_DATA_VRU = 2
};

/// Constant 'OPT_DATA_OBSTACLE'.
enum
{
  sdsm_msgs__msg__DetectedObjectData__OPT_DATA_OBSTACLE = 3
};

// Include directives for member types
// Member 'det_obj_common'
#include "sdsm_msgs/msg/detail/detected_object_common_data__struct.h"
// Member 'det_veh'
#include "sdsm_msgs/msg/detail/detected_vehicle_data__struct.h"
// Member 'det_vru'
#include "sdsm_msgs/msg/detail/detected_vru_data__struct.h"
// Member 'det_obst'
#include "sdsm_msgs/msg/detail/detected_obstacle_data__struct.h"

/// Struct defined in msg/DetectedObjectData in the package sdsm_msgs.
/**
  * Detected object container
 */
typedef struct sdsm_msgs__msg__DetectedObjectData
{
  sdsm_msgs__msg__DetectedObjectCommonData det_obj_common;
  /// CHOICE discriminator: only one of det_veh/det_vru/det_obst is valid
  /// Check this field before reading type-specific data
  /// 0=none, 1=vehicle, 2=VRU, 3=obstacle
  uint8_t det_obj_opt_kind;
  /// Vehicle-specific data (valid only when det_obj_opt_kind == OPT_DATA_VEHICLE)
  sdsm_msgs__msg__DetectedVehicleData det_veh;
  /// VRU-specific data (valid only when det_obj_opt_kind == OPT_DATA_VRU)
  sdsm_msgs__msg__DetectedVRUData det_vru;
  /// Obstacle-specific data (valid only when det_obj_opt_kind == OPT_DATA_OBSTACLE)
  sdsm_msgs__msg__DetectedObstacleData det_obst;
} sdsm_msgs__msg__DetectedObjectData;

// Struct for a sequence of sdsm_msgs__msg__DetectedObjectData.
typedef struct sdsm_msgs__msg__DetectedObjectData__Sequence
{
  sdsm_msgs__msg__DetectedObjectData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__DetectedObjectData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__STRUCT_H_
