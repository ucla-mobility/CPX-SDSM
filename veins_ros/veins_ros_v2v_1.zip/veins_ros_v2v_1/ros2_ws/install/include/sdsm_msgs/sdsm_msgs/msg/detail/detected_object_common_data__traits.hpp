// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sdsm_msgs:msg\DetectedObjectCommonData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_object_common_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__TRAITS_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sdsm_msgs/msg/detail/detected_object_common_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'pos'
#include "sdsm_msgs/msg/detail/position_offset_xyz__traits.hpp"
// Member 'pos_confidence'
#include "sdsm_msgs/msg/detail/position_confidence_set__traits.hpp"

namespace sdsm_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DetectedObjectCommonData & msg,
  std::ostream & out)
{
  out << "{";
  // member: obj_type
  {
    out << "obj_type: ";
    rosidl_generator_traits::value_to_yaml(msg.obj_type, out);
    out << ", ";
  }

  // member: obj_type_cfd
  {
    out << "obj_type_cfd: ";
    rosidl_generator_traits::value_to_yaml(msg.obj_type_cfd, out);
    out << ", ";
  }

  // member: object_id
  {
    out << "object_id: ";
    rosidl_generator_traits::value_to_yaml(msg.object_id, out);
    out << ", ";
  }

  // member: measurement_time
  {
    out << "measurement_time: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_time, out);
    out << ", ";
  }

  // member: pos
  {
    out << "pos: ";
    to_flow_style_yaml(msg.pos, out);
    out << ", ";
  }

  // member: pos_confidence
  {
    out << "pos_confidence: ";
    to_flow_style_yaml(msg.pos_confidence, out);
    out << ", ";
  }

  // member: speed
  {
    out << "speed: ";
    rosidl_generator_traits::value_to_yaml(msg.speed, out);
    out << ", ";
  }

  // member: speed_z
  {
    out << "speed_z: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_z, out);
    out << ", ";
  }

  // member: has_speed_z
  {
    out << "has_speed_z: ";
    rosidl_generator_traits::value_to_yaml(msg.has_speed_z, out);
    out << ", ";
  }

  // member: heading
  {
    out << "heading: ";
    rosidl_generator_traits::value_to_yaml(msg.heading, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DetectedObjectCommonData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: obj_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obj_type: ";
    rosidl_generator_traits::value_to_yaml(msg.obj_type, out);
    out << "\n";
  }

  // member: obj_type_cfd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obj_type_cfd: ";
    rosidl_generator_traits::value_to_yaml(msg.obj_type_cfd, out);
    out << "\n";
  }

  // member: object_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "object_id: ";
    rosidl_generator_traits::value_to_yaml(msg.object_id, out);
    out << "\n";
  }

  // member: measurement_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measurement_time: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_time, out);
    out << "\n";
  }

  // member: pos
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pos:\n";
    to_block_style_yaml(msg.pos, out, indentation + 2);
  }

  // member: pos_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pos_confidence:\n";
    to_block_style_yaml(msg.pos_confidence, out, indentation + 2);
  }

  // member: speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed: ";
    rosidl_generator_traits::value_to_yaml(msg.speed, out);
    out << "\n";
  }

  // member: speed_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed_z: ";
    rosidl_generator_traits::value_to_yaml(msg.speed_z, out);
    out << "\n";
  }

  // member: has_speed_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "has_speed_z: ";
    rosidl_generator_traits::value_to_yaml(msg.has_speed_z, out);
    out << "\n";
  }

  // member: heading
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "heading: ";
    rosidl_generator_traits::value_to_yaml(msg.heading, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DetectedObjectCommonData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sdsm_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sdsm_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sdsm_msgs::msg::DetectedObjectCommonData & msg,
  std::ostream & out, size_t indentation = 0)
{
  sdsm_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sdsm_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sdsm_msgs::msg::DetectedObjectCommonData & msg)
{
  return sdsm_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sdsm_msgs::msg::DetectedObjectCommonData>()
{
  return "sdsm_msgs::msg::DetectedObjectCommonData";
}

template<>
inline const char * name<sdsm_msgs::msg::DetectedObjectCommonData>()
{
  return "sdsm_msgs/msg/DetectedObjectCommonData";
}

template<>
struct has_fixed_size<sdsm_msgs::msg::DetectedObjectCommonData>
  : std::integral_constant<bool, has_fixed_size<sdsm_msgs::msg::PositionConfidenceSet>::value && has_fixed_size<sdsm_msgs::msg::PositionOffsetXYZ>::value> {};

template<>
struct has_bounded_size<sdsm_msgs::msg::DetectedObjectCommonData>
  : std::integral_constant<bool, has_bounded_size<sdsm_msgs::msg::PositionConfidenceSet>::value && has_bounded_size<sdsm_msgs::msg::PositionOffsetXYZ>::value> {};

template<>
struct is_message<sdsm_msgs::msg::DetectedObjectCommonData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__TRAITS_HPP_
