// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__SENSOR_DATA_SHARING_MESSAGE_HPP_
#define SDSM_MSGS__MSG__SENSOR_DATA_SHARING_MESSAGE_HPP_

#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__struct.hpp"
#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__builder.hpp"
#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__traits.hpp"
#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__type_support.hpp"

#endif  // SDSM_MSGS__MSG__SENSOR_DATA_SHARING_MESSAGE_HPP_
