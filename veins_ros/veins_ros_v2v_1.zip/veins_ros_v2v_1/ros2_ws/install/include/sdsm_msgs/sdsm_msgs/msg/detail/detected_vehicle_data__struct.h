// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\DetectedVehicleData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_vehicle_data.h"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_VEHICLE_DATA__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_VEHICLE_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'size'
#include "sdsm_msgs/msg/detail/vehicle_size__struct.h"

/// Struct defined in msg/DetectedVehicleData in the package sdsm_msgs.
/**
  * Vehicle-specific data
 */
typedef struct sdsm_msgs__msg__DetectedVehicleData
{
  /// Vehicle dimensions (width/length in cm)
  /// Optional per ASN.1; check has_size before use
  sdsm_msgs__msg__VehicleSize size;
  bool has_size;
  /// Vehicle height (5 cm units, 0-127, 0=unavailable)
  /// Separate from size because height uses different units per J2735
  uint16_t height;
  bool has_height;
  /// Basic vehicle class (per J2735 BasicVehicleClass)
  /// Categories: passenger, truck, bus, motorcycle, etc.
  uint8_t vehicle_class;
  bool has_vehicle_class;
  /// 0=unknown, 1-100=confidence %, 101=unavailable
  uint8_t class_conf;
  bool has_class_conf;
} sdsm_msgs__msg__DetectedVehicleData;

// Struct for a sequence of sdsm_msgs__msg__DetectedVehicleData.
typedef struct sdsm_msgs__msg__DetectedVehicleData__Sequence
{
  sdsm_msgs__msg__DetectedVehicleData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__DetectedVehicleData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_VEHICLE_DATA__STRUCT_H_
