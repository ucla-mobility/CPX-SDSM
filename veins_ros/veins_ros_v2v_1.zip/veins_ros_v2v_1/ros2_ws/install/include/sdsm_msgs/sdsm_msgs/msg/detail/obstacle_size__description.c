// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\ObstacleSize.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/obstacle_size__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__ObstacleSize__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x24, 0x88, 0x38, 0xf2, 0x59, 0x79, 0xd2, 0x01,
      0xf6, 0x0a, 0x21, 0x46, 0x56, 0x0d, 0xe2, 0xdd,
      0xd3, 0x63, 0xf6, 0x5b, 0xe0, 0xb3, 0xa1, 0x75,
      0x75, 0xc4, 0x58, 0xaf, 0x2b, 0x11, 0x66, 0x19,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char sdsm_msgs__msg__ObstacleSize__TYPE_NAME[] = "sdsm_msgs/msg/ObstacleSize";

// Define type names, field names, and default values
static char sdsm_msgs__msg__ObstacleSize__FIELD_NAME__width[] = "width";
static char sdsm_msgs__msg__ObstacleSize__FIELD_NAME__length[] = "length";
static char sdsm_msgs__msg__ObstacleSize__FIELD_NAME__height[] = "height";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__ObstacleSize__FIELDS[] = {
  {
    {sdsm_msgs__msg__ObstacleSize__FIELD_NAME__width, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__ObstacleSize__FIELD_NAME__length, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__ObstacleSize__FIELD_NAME__height, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__ObstacleSize__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__ObstacleSize__TYPE_NAME, 26, 26},
      {sdsm_msgs__msg__ObstacleSize__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Obstacle dimensions\n"
  "# Uses 10 cm units (coarser than vehicle size) because obstacles are less precisely measured\n"
  "\n"
  "uint16 width  # 10 cm units, 0=unavailable\n"
  "uint16 length  # 10 cm units, 0=unavailable\n"
  "uint16 height  # 10 cm units, 0=unavailable";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__ObstacleSize__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__ObstacleSize__TYPE_NAME, 26, 26},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 247, 247},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__ObstacleSize__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__ObstacleSize__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
