// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\DDateTime.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/d_date_time.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/d_date_time__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_DDateTime_time_of_day
{
public:
  explicit Init_DDateTime_time_of_day(::sdsm_msgs::msg::DDateTime & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::DDateTime time_of_day(::sdsm_msgs::msg::DDateTime::_time_of_day_type arg)
  {
    msg_.time_of_day = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::DDateTime msg_;
};

class Init_DDateTime_day_of_month
{
public:
  Init_DDateTime_day_of_month()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DDateTime_time_of_day day_of_month(::sdsm_msgs::msg::DDateTime::_day_of_month_type arg)
  {
    msg_.day_of_month = std::move(arg);
    return Init_DDateTime_time_of_day(msg_);
  }

private:
  ::sdsm_msgs::msg::DDateTime msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::DDateTime>()
{
  return sdsm_msgs::msg::builder::Init_DDateTime_day_of_month();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__D_DATE_TIME__BUILDER_HPP_
