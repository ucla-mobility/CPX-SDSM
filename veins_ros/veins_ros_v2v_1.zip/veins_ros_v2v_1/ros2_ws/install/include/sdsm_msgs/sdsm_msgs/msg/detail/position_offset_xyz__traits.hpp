// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sdsm_msgs:msg\PositionOffsetXYZ.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position_offset_xyz.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__TRAITS_HPP_
#define SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sdsm_msgs/msg/detail/position_offset_xyz__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace sdsm_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const PositionOffsetXYZ & msg,
  std::ostream & out)
{
  out << "{";
  // member: offset_x
  {
    out << "offset_x: ";
    rosidl_generator_traits::value_to_yaml(msg.offset_x, out);
    out << ", ";
  }

  // member: offset_y
  {
    out << "offset_y: ";
    rosidl_generator_traits::value_to_yaml(msg.offset_y, out);
    out << ", ";
  }

  // member: offset_z
  {
    out << "offset_z: ";
    rosidl_generator_traits::value_to_yaml(msg.offset_z, out);
    out << ", ";
  }

  // member: has_offset_z
  {
    out << "has_offset_z: ";
    rosidl_generator_traits::value_to_yaml(msg.has_offset_z, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const PositionOffsetXYZ & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: offset_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "offset_x: ";
    rosidl_generator_traits::value_to_yaml(msg.offset_x, out);
    out << "\n";
  }

  // member: offset_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "offset_y: ";
    rosidl_generator_traits::value_to_yaml(msg.offset_y, out);
    out << "\n";
  }

  // member: offset_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "offset_z: ";
    rosidl_generator_traits::value_to_yaml(msg.offset_z, out);
    out << "\n";
  }

  // member: has_offset_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "has_offset_z: ";
    rosidl_generator_traits::value_to_yaml(msg.has_offset_z, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const PositionOffsetXYZ & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sdsm_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sdsm_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sdsm_msgs::msg::PositionOffsetXYZ & msg,
  std::ostream & out, size_t indentation = 0)
{
  sdsm_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sdsm_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sdsm_msgs::msg::PositionOffsetXYZ & msg)
{
  return sdsm_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sdsm_msgs::msg::PositionOffsetXYZ>()
{
  return "sdsm_msgs::msg::PositionOffsetXYZ";
}

template<>
inline const char * name<sdsm_msgs::msg::PositionOffsetXYZ>()
{
  return "sdsm_msgs/msg/PositionOffsetXYZ";
}

template<>
struct has_fixed_size<sdsm_msgs::msg::PositionOffsetXYZ>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<sdsm_msgs::msg::PositionOffsetXYZ>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<sdsm_msgs::msg::PositionOffsetXYZ>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__TRAITS_HPP_
