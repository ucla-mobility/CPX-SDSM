// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\DetectedVehicleData.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/detected_vehicle_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__DetectedVehicleData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x31, 0x22, 0x70, 0x9d, 0xc8, 0xcc, 0x6f, 0x1c,
      0x2a, 0x20, 0xf9, 0x62, 0xa5, 0x35, 0x09, 0xd0,
      0xa6, 0xb8, 0xf2, 0xc1, 0x68, 0x8f, 0xfd, 0x71,
      0x45, 0xcf, 0xf0, 0x44, 0x44, 0x2a, 0x21, 0x39,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "sdsm_msgs/msg/detail/vehicle_size__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t sdsm_msgs__msg__VehicleSize__EXPECTED_HASH = {1, {
    0x3d, 0xeb, 0xe5, 0x1b, 0x9f, 0x33, 0x4c, 0xe3,
    0xbe, 0x5f, 0xf5, 0xed, 0x84, 0xc9, 0x1e, 0xfd,
    0x50, 0x76, 0xac, 0xcb, 0x5f, 0xbf, 0x60, 0x4a,
    0x3f, 0xfc, 0x20, 0x1b, 0x8c, 0x74, 0x51, 0x28,
  }};
#endif

static char sdsm_msgs__msg__DetectedVehicleData__TYPE_NAME[] = "sdsm_msgs/msg/DetectedVehicleData";
static char sdsm_msgs__msg__VehicleSize__TYPE_NAME[] = "sdsm_msgs/msg/VehicleSize";

// Define type names, field names, and default values
static char sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__size[] = "size";
static char sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__has_size[] = "has_size";
static char sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__height[] = "height";
static char sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__has_height[] = "has_height";
static char sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__vehicle_class[] = "vehicle_class";
static char sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__has_vehicle_class[] = "has_vehicle_class";
static char sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__class_conf[] = "class_conf";
static char sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__has_class_conf[] = "has_class_conf";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__DetectedVehicleData__FIELDS[] = {
  {
    {sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__size, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {sdsm_msgs__msg__VehicleSize__TYPE_NAME, 25, 25},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__has_size, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__height, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__has_height, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__vehicle_class, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__has_vehicle_class, 17, 17},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__class_conf, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__DetectedVehicleData__FIELD_NAME__has_class_conf, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription sdsm_msgs__msg__DetectedVehicleData__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {sdsm_msgs__msg__VehicleSize__TYPE_NAME, 25, 25},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__DetectedVehicleData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__DetectedVehicleData__TYPE_NAME, 33, 33},
      {sdsm_msgs__msg__DetectedVehicleData__FIELDS, 8, 8},
    },
    {sdsm_msgs__msg__DetectedVehicleData__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&sdsm_msgs__msg__VehicleSize__EXPECTED_HASH, sdsm_msgs__msg__VehicleSize__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = sdsm_msgs__msg__VehicleSize__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Vehicle-specific data\n"
  "\n"
  "# Vehicle dimensions (width/length in cm)\n"
  "# Optional per ASN.1; check has_size before use\n"
  "sdsm_msgs/VehicleSize size\n"
  "bool has_size\n"
  "\n"
  "# Vehicle height (5 cm units, 0-127, 0=unavailable)\n"
  "# Separate from size because height uses different units per J2735\n"
  "uint16 height\n"
  "bool has_height\n"
  "\n"
  "# Basic vehicle class (per J2735 BasicVehicleClass)\n"
  "# Categories: passenger, truck, bus, motorcycle, etc.\n"
  "uint8 vehicle_class\n"
  "bool has_vehicle_class\n"
  "\n"
  "uint8 class_conf  # 0=unknown, 1-100=confidence %, 101=unavailable\n"
  "bool has_class_conf";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__DetectedVehicleData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__DetectedVehicleData__TYPE_NAME, 33, 33},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 544, 544},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__DetectedVehicleData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__DetectedVehicleData__get_individual_type_description_source(NULL),
    sources[1] = *sdsm_msgs__msg__VehicleSize__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
