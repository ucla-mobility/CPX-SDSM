// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\DetectedVRUData.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/detected_vru_data__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__DetectedVRUData__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x30, 0xce, 0xa8, 0xd0, 0x0d, 0x58, 0x5e, 0xd8,
      0xfc, 0xa5, 0x4b, 0xc7, 0x10, 0xaa, 0x37, 0x5b,
      0x38, 0xfa, 0x37, 0x92, 0x2c, 0x68, 0xc1, 0x36,
      0x7f, 0x16, 0x4c, 0x7b, 0x9c, 0x98, 0xc7, 0x65,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char sdsm_msgs__msg__DetectedVRUData__TYPE_NAME[] = "sdsm_msgs/msg/DetectedVRUData";

// Define type names, field names, and default values
static char sdsm_msgs__msg__DetectedVRUData__FIELD_NAME__basic_type[] = "basic_type";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__DetectedVRUData__FIELDS[] = {
  {
    {sdsm_msgs__msg__DetectedVRUData__FIELD_NAME__basic_type, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__DetectedVRUData__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__DetectedVRUData__TYPE_NAME, 29, 29},
      {sdsm_msgs__msg__DetectedVRUData__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# VRU (Vulnerable Road User) specific data\n"
  "\n"
  "uint8 VRU_TYPE_UNAVAILABLE = 0\n"
  "uint8 VRU_TYPE_PEDESTRIAN = 1\n"
  "uint8 VRU_TYPE_PEDALCYCLIST = 2\n"
  "uint8 VRU_TYPE_PUBLIC_SAFETY_WORKER = 3\n"
  "uint8 VRU_TYPE_ANIMAL = 4\n"
  "\n"
  "# VRU basic type (use VRU_TYPE_* constants)\n"
  "# Classifies vulnerable road user: pedestrian, cyclist, worker, or animal\n"
  "uint8 basic_type";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__DetectedVRUData__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__DetectedVRUData__TYPE_NAME, 29, 29},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 339, 339},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__DetectedVRUData__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__DetectedVRUData__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
