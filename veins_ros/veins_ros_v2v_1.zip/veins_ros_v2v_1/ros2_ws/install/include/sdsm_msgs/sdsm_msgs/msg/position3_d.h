// generated from rosidl_generator_c/resource/idl.h.em
// with input from sdsm_msgs:msg\Position3D.idl
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__POSITION3_D_H_
#define SDSM_MSGS__MSG__POSITION3_D_H_

#include "sdsm_msgs/msg/detail/position3_d__struct.h"
#include "sdsm_msgs/msg/detail/position3_d__functions.h"
#include "sdsm_msgs/msg/detail/position3_d__type_support.h"

#endif  // SDSM_MSGS__MSG__POSITION3_D_H_
