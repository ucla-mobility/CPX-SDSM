// generated from rosidl_generator_c/resource/idl.h.em
// with input from sdsm_msgs:msg\DDateTime.idl
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__D_DATE_TIME_H_
#define SDSM_MSGS__MSG__D_DATE_TIME_H_

#include "sdsm_msgs/msg/detail/d_date_time__struct.h"
#include "sdsm_msgs/msg/detail/d_date_time__functions.h"
#include "sdsm_msgs/msg/detail/d_date_time__type_support.h"

#endif  // SDSM_MSGS__MSG__D_DATE_TIME_H_
