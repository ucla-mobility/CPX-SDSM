﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\DetectedObjectCommonData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_object_common_data.h"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Constant 'OBJ_TYPE_UNKNOWN'.
enum
{
  sdsm_msgs__msg__DetectedObjectCommonData__OBJ_TYPE_UNKNOWN = 0
};

/// Constant 'OBJ_TYPE_VEHICLE'.
enum
{
  sdsm_msgs__msg__DetectedObjectCommonData__OBJ_TYPE_VEHICLE = 1
};

/// Constant 'OBJ_TYPE_VRU'.
enum
{
  sdsm_msgs__msg__DetectedObjectCommonData__OBJ_TYPE_VRU = 2
};

/// Constant 'OBJ_TYPE_ANIMAL'.
enum
{
  sdsm_msgs__msg__DetectedObjectCommonData__OBJ_TYPE_ANIMAL = 3
};

/// Constant 'OBJ_TYPE_OBSTACLE'.
enum
{
  sdsm_msgs__msg__DetectedObjectCommonData__OBJ_TYPE_OBSTACLE = 4
};

// Include directives for member types
// Member 'pos'
#include "sdsm_msgs/msg/detail/position_offset_xyz__struct.h"
// Member 'pos_confidence'
#include "sdsm_msgs/msg/detail/position_confidence_set__struct.h"

/// Struct defined in msg/DetectedObjectCommonData in the package sdsm_msgs.
/**
  * Common data for detected object
 */
typedef struct sdsm_msgs__msg__DetectedObjectCommonData
{
  /// Object type (use OBJ_TYPE_* constants)
  /// High-level classification: vehicle, VRU, animal, or obstacle
  uint8_t obj_type;
  /// Classification confidence (0=unknown, 1-100=confidence %, 101=unavailable)
  uint8_t obj_type_cfd;
  /// Temporary object ID assigned by source
  /// Unique within this message; used for tracking objects across multiple SDSM messages
  uint16_t object_id;
  /// Measurement time offset from sDSMTimeStamp (ms, -1500..1500)
  /// Relative to message timestamp; allows objects detected at different times
  /// Negative = detected before message timestamp, positive = after
  int16_t measurement_time;
  /// Position offset relative to sender's refPos
  /// Uses relative coordinates for efficiency and coordinate system independence
  sdsm_msgs__msg__PositionOffsetXYZ pos;
  /// Position confidence values (per J2735)
  /// Indicates accuracy of position measurements
  sdsm_msgs__msg__PositionConfidenceSet pos_confidence;
  /// Ground speed (0.02 m/s units, 8191=unavailable)
  uint16_t speed;
  /// Z-axis speed (0.02 m/s units, 8191=unavailable)
  /// Vertical velocity; optional because most objects move on ground plane
  uint16_t speed_z;
  bool has_speed_z;
  /// Heading (0.0125 deg units, 0-28799, 28800=unavailable)
  /// Direction of travel in degrees (0-359.9875°); 0.0125° precision per J2735
  uint16_t heading;
} sdsm_msgs__msg__DetectedObjectCommonData;

// Struct for a sequence of sdsm_msgs__msg__DetectedObjectCommonData.
typedef struct sdsm_msgs__msg__DetectedObjectCommonData__Sequence
{
  sdsm_msgs__msg__DetectedObjectCommonData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__DetectedObjectCommonData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_COMMON_DATA__STRUCT_H_
