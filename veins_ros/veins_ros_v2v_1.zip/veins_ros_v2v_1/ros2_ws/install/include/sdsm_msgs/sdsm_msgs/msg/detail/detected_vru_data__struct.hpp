// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\DetectedVRUData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_vru_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__DetectedVRUData __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__DetectedVRUData __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DetectedVRUData_
{
  using Type = DetectedVRUData_<ContainerAllocator>;

  explicit DetectedVRUData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->basic_type = 0;
    }
  }

  explicit DetectedVRUData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->basic_type = 0;
    }
  }

  // field types and members
  using _basic_type_type =
    uint8_t;
  _basic_type_type basic_type;

  // setters for named parameter idiom
  Type & set__basic_type(
    const uint8_t & _arg)
  {
    this->basic_type = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t VRU_TYPE_UNAVAILABLE =
    0u;
  static constexpr uint8_t VRU_TYPE_PEDESTRIAN =
    1u;
  static constexpr uint8_t VRU_TYPE_PEDALCYCLIST =
    2u;
  static constexpr uint8_t VRU_TYPE_PUBLIC_SAFETY_WORKER =
    3u;
  static constexpr uint8_t VRU_TYPE_ANIMAL =
    4u;

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__DetectedVRUData
    std::shared_ptr<sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__DetectedVRUData
    std::shared_ptr<sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DetectedVRUData_ & other) const
  {
    if (this->basic_type != other.basic_type) {
      return false;
    }
    return true;
  }
  bool operator!=(const DetectedVRUData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DetectedVRUData_

// alias to use template instance with default allocator
using DetectedVRUData =
  sdsm_msgs::msg::DetectedVRUData_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedVRUData_<ContainerAllocator>::VRU_TYPE_UNAVAILABLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedVRUData_<ContainerAllocator>::VRU_TYPE_PEDESTRIAN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedVRUData_<ContainerAllocator>::VRU_TYPE_PEDALCYCLIST;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedVRUData_<ContainerAllocator>::VRU_TYPE_PUBLIC_SAFETY_WORKER;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedVRUData_<ContainerAllocator>::VRU_TYPE_ANIMAL;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__STRUCT_HPP_
