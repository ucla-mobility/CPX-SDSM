// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__POSITION_OFFSET_XYZ_HPP_
#define SDSM_MSGS__MSG__POSITION_OFFSET_XYZ_HPP_

#include "sdsm_msgs/msg/detail/position_offset_xyz__struct.hpp"
#include "sdsm_msgs/msg/detail/position_offset_xyz__builder.hpp"
#include "sdsm_msgs/msg/detail/position_offset_xyz__traits.hpp"
#include "sdsm_msgs/msg/detail/position_offset_xyz__type_support.hpp"

#endif  // SDSM_MSGS__MSG__POSITION_OFFSET_XYZ_HPP_
