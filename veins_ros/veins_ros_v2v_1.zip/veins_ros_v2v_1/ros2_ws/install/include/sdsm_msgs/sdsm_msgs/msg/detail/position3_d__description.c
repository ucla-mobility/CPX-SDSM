// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\Position3D.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/position3_d__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__Position3D__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x62, 0xd6, 0x44, 0x1f, 0x89, 0xd9, 0x94, 0xbe,
      0xfd, 0xd8, 0x2c, 0xa7, 0x5f, 0xbc, 0x2a, 0x35,
      0x58, 0x7e, 0xd9, 0xde, 0x75, 0xde, 0x33, 0x80,
      0x7e, 0x6e, 0x00, 0x0f, 0xd7, 0x56, 0x77, 0x87,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char sdsm_msgs__msg__Position3D__TYPE_NAME[] = "sdsm_msgs/msg/Position3D";

// Define type names, field names, and default values
static char sdsm_msgs__msg__Position3D__FIELD_NAME__lat[] = "lat";
static char sdsm_msgs__msg__Position3D__FIELD_NAME__lon[] = "lon";
static char sdsm_msgs__msg__Position3D__FIELD_NAME__elevation[] = "elevation";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__Position3D__FIELDS[] = {
  {
    {sdsm_msgs__msg__Position3D__FIELD_NAME__lat, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__Position3D__FIELD_NAME__lon, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__Position3D__FIELD_NAME__elevation, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__Position3D__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__Position3D__TYPE_NAME, 24, 24},
      {sdsm_msgs__msg__Position3D__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Reference position (J2735)\n"
  "# Sender's absolute geographic position; used as origin for object offsets\n"
  "\n"
  "# Latitude (1/10 microdegree units)\n"
  "# Precision: 0.0000001 degrees (J2735 standard)\n"
  "int32 lat\n"
  "\n"
  "# Longitude (1/10 microdegree units)\n"
  "# Precision: 0.0000001 degrees (J2735 standard)\n"
  "int32 lon\n"
  "\n"
  "# Elevation (10 cm units, -4096..61439, -4096=unknown)\n"
  "# Height above sea level; -4096 indicates elevation not available\n"
  "int32 elevation";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__Position3D__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__Position3D__TYPE_NAME, 24, 24},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 433, 433},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__Position3D__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__Position3D__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
