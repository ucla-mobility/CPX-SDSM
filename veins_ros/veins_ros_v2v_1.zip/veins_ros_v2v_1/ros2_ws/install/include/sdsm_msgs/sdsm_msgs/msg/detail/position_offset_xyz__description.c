// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from sdsm_msgs:msg\PositionOffsetXYZ.idl
// generated code does not contain a copyright notice

#include "sdsm_msgs/msg/detail/position_offset_xyz__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_sdsm_msgs
const rosidl_type_hash_t *
sdsm_msgs__msg__PositionOffsetXYZ__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x21, 0x9d, 0x59, 0x90, 0x43, 0x5e, 0x11, 0x66,
      0x8c, 0x1d, 0x39, 0x31, 0x3d, 0xba, 0x9d, 0x4d,
      0xa5, 0x41, 0x17, 0xca, 0x03, 0x0e, 0xed, 0x94,
      0xd2, 0x33, 0x82, 0x75, 0x10, 0x57, 0x8b, 0xce,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char sdsm_msgs__msg__PositionOffsetXYZ__TYPE_NAME[] = "sdsm_msgs/msg/PositionOffsetXYZ";

// Define type names, field names, and default values
static char sdsm_msgs__msg__PositionOffsetXYZ__FIELD_NAME__offset_x[] = "offset_x";
static char sdsm_msgs__msg__PositionOffsetXYZ__FIELD_NAME__offset_y[] = "offset_y";
static char sdsm_msgs__msg__PositionOffsetXYZ__FIELD_NAME__offset_z[] = "offset_z";
static char sdsm_msgs__msg__PositionOffsetXYZ__FIELD_NAME__has_offset_z[] = "has_offset_z";

static rosidl_runtime_c__type_description__Field sdsm_msgs__msg__PositionOffsetXYZ__FIELDS[] = {
  {
    {sdsm_msgs__msg__PositionOffsetXYZ__FIELD_NAME__offset_x, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__PositionOffsetXYZ__FIELD_NAME__offset_y, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__PositionOffsetXYZ__FIELD_NAME__offset_z, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {sdsm_msgs__msg__PositionOffsetXYZ__FIELD_NAME__has_offset_z, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
sdsm_msgs__msg__PositionOffsetXYZ__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {sdsm_msgs__msg__PositionOffsetXYZ__TYPE_NAME, 31, 31},
      {sdsm_msgs__msg__PositionOffsetXYZ__FIELDS, 4, 4},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# Position offset relative to refPos\n"
  "# Relative coordinates avoid coordinate system conversions and improve precision\n"
  "\n"
  "# X offset (0.1 m units)\n"
  "# Lateral offset from sender (left/right)\n"
  "int16 offset_x\n"
  "\n"
  "# Y offset (0.1 m units)\n"
  "# Longitudinal offset from sender (forward/backward)\n"
  "int16 offset_y\n"
  "\n"
  "# Z offset (0.1 m units)\n"
  "# Vertical offset; optional because most objects are on ground plane\n"
  "int16 offset_z\n"
  "bool has_offset_z";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
sdsm_msgs__msg__PositionOffsetXYZ__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {sdsm_msgs__msg__PositionOffsetXYZ__TYPE_NAME, 31, 31},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 423, 423},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
sdsm_msgs__msg__PositionOffsetXYZ__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *sdsm_msgs__msg__PositionOffsetXYZ__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
