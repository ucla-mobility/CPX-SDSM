// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\Position3D.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position3_d.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION3_D__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__POSITION3_D__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/position3_d__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_Position3D_elevation
{
public:
  explicit Init_Position3D_elevation(::sdsm_msgs::msg::Position3D & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::Position3D elevation(::sdsm_msgs::msg::Position3D::_elevation_type arg)
  {
    msg_.elevation = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::Position3D msg_;
};

class Init_Position3D_lon
{
public:
  explicit Init_Position3D_lon(::sdsm_msgs::msg::Position3D & msg)
  : msg_(msg)
  {}
  Init_Position3D_elevation lon(::sdsm_msgs::msg::Position3D::_lon_type arg)
  {
    msg_.lon = std::move(arg);
    return Init_Position3D_elevation(msg_);
  }

private:
  ::sdsm_msgs::msg::Position3D msg_;
};

class Init_Position3D_lat
{
public:
  Init_Position3D_lat()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Position3D_lon lat(::sdsm_msgs::msg::Position3D::_lat_type arg)
  {
    msg_.lat = std::move(arg);
    return Init_Position3D_lon(msg_);
  }

private:
  ::sdsm_msgs::msg::Position3D msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::Position3D>()
{
  return sdsm_msgs::msg::builder::Init_Position3D_lat();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION3_D__BUILDER_HPP_
