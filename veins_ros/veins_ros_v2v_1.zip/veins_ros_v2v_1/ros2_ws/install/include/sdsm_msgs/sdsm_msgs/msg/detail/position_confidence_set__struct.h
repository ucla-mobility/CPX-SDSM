// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\PositionConfidenceSet.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position_confidence_set.h"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/PositionConfidenceSet in the package sdsm_msgs.
/**
  * Position confidence (J2735)
  * Indicates accuracy of position measurements; higher values = better confidence
  * Placeholder structure; full J2735 confidence enums deferred to ORANGE fields
 */
typedef struct sdsm_msgs__msg__PositionConfidenceSet
{
  /// 0=unavailable
  uint8_t pos_confidence;
  /// 0=unavailable
  uint8_t elevation_confidence;
} sdsm_msgs__msg__PositionConfidenceSet;

// Struct for a sequence of sdsm_msgs__msg__PositionConfidenceSet.
typedef struct sdsm_msgs__msg__PositionConfidenceSet__Sequence
{
  sdsm_msgs__msg__PositionConfidenceSet * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__PositionConfidenceSet__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION_CONFIDENCE_SET__STRUCT_H_
