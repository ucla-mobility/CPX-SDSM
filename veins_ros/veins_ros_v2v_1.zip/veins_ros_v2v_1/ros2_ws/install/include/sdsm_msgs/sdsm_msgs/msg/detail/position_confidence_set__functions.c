// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sdsm_msgs:msg\PositionConfidenceSet.idl
// generated code does not contain a copyright notice
#include "sdsm_msgs/msg/detail/position_confidence_set__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
sdsm_msgs__msg__PositionConfidenceSet__init(sdsm_msgs__msg__PositionConfidenceSet * msg)
{
  if (!msg) {
    return false;
  }
  // pos_confidence
  // elevation_confidence
  return true;
}

void
sdsm_msgs__msg__PositionConfidenceSet__fini(sdsm_msgs__msg__PositionConfidenceSet * msg)
{
  if (!msg) {
    return;
  }
  // pos_confidence
  // elevation_confidence
}

bool
sdsm_msgs__msg__PositionConfidenceSet__are_equal(const sdsm_msgs__msg__PositionConfidenceSet * lhs, const sdsm_msgs__msg__PositionConfidenceSet * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // pos_confidence
  if (lhs->pos_confidence != rhs->pos_confidence) {
    return false;
  }
  // elevation_confidence
  if (lhs->elevation_confidence != rhs->elevation_confidence) {
    return false;
  }
  return true;
}

bool
sdsm_msgs__msg__PositionConfidenceSet__copy(
  const sdsm_msgs__msg__PositionConfidenceSet * input,
  sdsm_msgs__msg__PositionConfidenceSet * output)
{
  if (!input || !output) {
    return false;
  }
  // pos_confidence
  output->pos_confidence = input->pos_confidence;
  // elevation_confidence
  output->elevation_confidence = input->elevation_confidence;
  return true;
}

sdsm_msgs__msg__PositionConfidenceSet *
sdsm_msgs__msg__PositionConfidenceSet__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__PositionConfidenceSet * msg = (sdsm_msgs__msg__PositionConfidenceSet *)allocator.allocate(sizeof(sdsm_msgs__msg__PositionConfidenceSet), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sdsm_msgs__msg__PositionConfidenceSet));
  bool success = sdsm_msgs__msg__PositionConfidenceSet__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sdsm_msgs__msg__PositionConfidenceSet__destroy(sdsm_msgs__msg__PositionConfidenceSet * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sdsm_msgs__msg__PositionConfidenceSet__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sdsm_msgs__msg__PositionConfidenceSet__Sequence__init(sdsm_msgs__msg__PositionConfidenceSet__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__PositionConfidenceSet * data = NULL;

  if (size) {
    data = (sdsm_msgs__msg__PositionConfidenceSet *)allocator.zero_allocate(size, sizeof(sdsm_msgs__msg__PositionConfidenceSet), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sdsm_msgs__msg__PositionConfidenceSet__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sdsm_msgs__msg__PositionConfidenceSet__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sdsm_msgs__msg__PositionConfidenceSet__Sequence__fini(sdsm_msgs__msg__PositionConfidenceSet__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sdsm_msgs__msg__PositionConfidenceSet__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sdsm_msgs__msg__PositionConfidenceSet__Sequence *
sdsm_msgs__msg__PositionConfidenceSet__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sdsm_msgs__msg__PositionConfidenceSet__Sequence * array = (sdsm_msgs__msg__PositionConfidenceSet__Sequence *)allocator.allocate(sizeof(sdsm_msgs__msg__PositionConfidenceSet__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sdsm_msgs__msg__PositionConfidenceSet__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sdsm_msgs__msg__PositionConfidenceSet__Sequence__destroy(sdsm_msgs__msg__PositionConfidenceSet__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sdsm_msgs__msg__PositionConfidenceSet__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sdsm_msgs__msg__PositionConfidenceSet__Sequence__are_equal(const sdsm_msgs__msg__PositionConfidenceSet__Sequence * lhs, const sdsm_msgs__msg__PositionConfidenceSet__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sdsm_msgs__msg__PositionConfidenceSet__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sdsm_msgs__msg__PositionConfidenceSet__Sequence__copy(
  const sdsm_msgs__msg__PositionConfidenceSet__Sequence * input,
  sdsm_msgs__msg__PositionConfidenceSet__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sdsm_msgs__msg__PositionConfidenceSet);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    sdsm_msgs__msg__PositionConfidenceSet * data =
      (sdsm_msgs__msg__PositionConfidenceSet *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sdsm_msgs__msg__PositionConfidenceSet__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          sdsm_msgs__msg__PositionConfidenceSet__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sdsm_msgs__msg__PositionConfidenceSet__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
