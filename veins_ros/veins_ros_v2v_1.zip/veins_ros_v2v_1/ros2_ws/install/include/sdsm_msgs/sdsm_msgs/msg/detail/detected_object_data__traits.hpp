// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sdsm_msgs:msg\DetectedObjectData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_object_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__TRAITS_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sdsm_msgs/msg/detail/detected_object_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'det_obj_common'
#include "sdsm_msgs/msg/detail/detected_object_common_data__traits.hpp"
// Member 'det_veh'
#include "sdsm_msgs/msg/detail/detected_vehicle_data__traits.hpp"
// Member 'det_vru'
#include "sdsm_msgs/msg/detail/detected_vru_data__traits.hpp"
// Member 'det_obst'
#include "sdsm_msgs/msg/detail/detected_obstacle_data__traits.hpp"

namespace sdsm_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DetectedObjectData & msg,
  std::ostream & out)
{
  out << "{";
  // member: det_obj_common
  {
    out << "det_obj_common: ";
    to_flow_style_yaml(msg.det_obj_common, out);
    out << ", ";
  }

  // member: det_obj_opt_kind
  {
    out << "det_obj_opt_kind: ";
    rosidl_generator_traits::value_to_yaml(msg.det_obj_opt_kind, out);
    out << ", ";
  }

  // member: det_veh
  {
    out << "det_veh: ";
    to_flow_style_yaml(msg.det_veh, out);
    out << ", ";
  }

  // member: det_vru
  {
    out << "det_vru: ";
    to_flow_style_yaml(msg.det_vru, out);
    out << ", ";
  }

  // member: det_obst
  {
    out << "det_obst: ";
    to_flow_style_yaml(msg.det_obst, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DetectedObjectData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: det_obj_common
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "det_obj_common:\n";
    to_block_style_yaml(msg.det_obj_common, out, indentation + 2);
  }

  // member: det_obj_opt_kind
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "det_obj_opt_kind: ";
    rosidl_generator_traits::value_to_yaml(msg.det_obj_opt_kind, out);
    out << "\n";
  }

  // member: det_veh
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "det_veh:\n";
    to_block_style_yaml(msg.det_veh, out, indentation + 2);
  }

  // member: det_vru
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "det_vru:\n";
    to_block_style_yaml(msg.det_vru, out, indentation + 2);
  }

  // member: det_obst
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "det_obst:\n";
    to_block_style_yaml(msg.det_obst, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DetectedObjectData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sdsm_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sdsm_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sdsm_msgs::msg::DetectedObjectData & msg,
  std::ostream & out, size_t indentation = 0)
{
  sdsm_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sdsm_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sdsm_msgs::msg::DetectedObjectData & msg)
{
  return sdsm_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sdsm_msgs::msg::DetectedObjectData>()
{
  return "sdsm_msgs::msg::DetectedObjectData";
}

template<>
inline const char * name<sdsm_msgs::msg::DetectedObjectData>()
{
  return "sdsm_msgs/msg/DetectedObjectData";
}

template<>
struct has_fixed_size<sdsm_msgs::msg::DetectedObjectData>
  : std::integral_constant<bool, has_fixed_size<sdsm_msgs::msg::DetectedObjectCommonData>::value && has_fixed_size<sdsm_msgs::msg::DetectedObstacleData>::value && has_fixed_size<sdsm_msgs::msg::DetectedVRUData>::value && has_fixed_size<sdsm_msgs::msg::DetectedVehicleData>::value> {};

template<>
struct has_bounded_size<sdsm_msgs::msg::DetectedObjectData>
  : std::integral_constant<bool, has_bounded_size<sdsm_msgs::msg::DetectedObjectCommonData>::value && has_bounded_size<sdsm_msgs::msg::DetectedObstacleData>::value && has_bounded_size<sdsm_msgs::msg::DetectedVRUData>::value && has_bounded_size<sdsm_msgs::msg::DetectedVehicleData>::value> {};

template<>
struct is_message<sdsm_msgs::msg::DetectedObjectData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__TRAITS_HPP_
