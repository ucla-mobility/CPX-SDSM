// generated from rosidl_generator_c/resource/idl.h.em
// with input from sdsm_msgs:msg\PositionConfidenceSet.idl
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__POSITION_CONFIDENCE_SET_H_
#define SDSM_MSGS__MSG__POSITION_CONFIDENCE_SET_H_

#include "sdsm_msgs/msg/detail/position_confidence_set__struct.h"
#include "sdsm_msgs/msg/detail/position_confidence_set__functions.h"
#include "sdsm_msgs/msg/detail/position_confidence_set__type_support.h"

#endif  // SDSM_MSGS__MSG__POSITION_CONFIDENCE_SET_H_
