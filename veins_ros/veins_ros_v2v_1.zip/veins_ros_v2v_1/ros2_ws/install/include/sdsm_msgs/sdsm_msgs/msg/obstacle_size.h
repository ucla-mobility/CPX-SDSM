// generated from rosidl_generator_c/resource/idl.h.em
// with input from sdsm_msgs:msg\ObstacleSize.idl
// generated code does not contain a copyright notice

#ifndef SDSM_MSGS__MSG__OBSTACLE_SIZE_H_
#define SDSM_MSGS__MSG__OBSTACLE_SIZE_H_

#include "sdsm_msgs/msg/detail/obstacle_size__struct.h"
#include "sdsm_msgs/msg/detail/obstacle_size__functions.h"
#include "sdsm_msgs/msg/detail/obstacle_size__type_support.h"

#endif  // SDSM_MSGS__MSG__OBSTACLE_SIZE_H_
