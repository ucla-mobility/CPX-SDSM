// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\SensorDataSharingMessage.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/sensor_data_sharing_message.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'sdsm_time_stamp'
#include "sdsm_msgs/msg/detail/d_date_time__struct.hpp"
// Member 'ref_pos'
#include "sdsm_msgs/msg/detail/position3_d__struct.hpp"
// Member 'objects'
#include "sdsm_msgs/msg/detail/detected_object_data__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__SensorDataSharingMessage __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__SensorDataSharingMessage __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SensorDataSharingMessage_
{
  using Type = SensorDataSharingMessage_<ContainerAllocator>;

  explicit SensorDataSharingMessage_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : sdsm_time_stamp(_init),
    ref_pos(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->msg_cnt = 0;
      std::fill<typename std::array<uint8_t, 4>::iterator, uint8_t>(this->source_id.begin(), this->source_id.end(), 0);
      this->equipment_type = 0;
    }
  }

  explicit SensorDataSharingMessage_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : source_id(_alloc),
    sdsm_time_stamp(_alloc, _init),
    ref_pos(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->msg_cnt = 0;
      std::fill<typename std::array<uint8_t, 4>::iterator, uint8_t>(this->source_id.begin(), this->source_id.end(), 0);
      this->equipment_type = 0;
    }
  }

  // field types and members
  using _msg_cnt_type =
    uint8_t;
  _msg_cnt_type msg_cnt;
  using _source_id_type =
    std::array<uint8_t, 4>;
  _source_id_type source_id;
  using _equipment_type_type =
    uint8_t;
  _equipment_type_type equipment_type;
  using _sdsm_time_stamp_type =
    sdsm_msgs::msg::DDateTime_<ContainerAllocator>;
  _sdsm_time_stamp_type sdsm_time_stamp;
  using _ref_pos_type =
    sdsm_msgs::msg::Position3D_<ContainerAllocator>;
  _ref_pos_type ref_pos;
  using _objects_type =
    std::vector<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>>>;
  _objects_type objects;

  // setters for named parameter idiom
  Type & set__msg_cnt(
    const uint8_t & _arg)
  {
    this->msg_cnt = _arg;
    return *this;
  }
  Type & set__source_id(
    const std::array<uint8_t, 4> & _arg)
  {
    this->source_id = _arg;
    return *this;
  }
  Type & set__equipment_type(
    const uint8_t & _arg)
  {
    this->equipment_type = _arg;
    return *this;
  }
  Type & set__sdsm_time_stamp(
    const sdsm_msgs::msg::DDateTime_<ContainerAllocator> & _arg)
  {
    this->sdsm_time_stamp = _arg;
    return *this;
  }
  Type & set__ref_pos(
    const sdsm_msgs::msg::Position3D_<ContainerAllocator> & _arg)
  {
    this->ref_pos = _arg;
    return *this;
  }
  Type & set__objects(
    const std::vector<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>>> & _arg)
  {
    this->objects = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t EQUIPMENT_TYPE_UNKNOWN =
    0u;
  static constexpr uint8_t EQUIPMENT_TYPE_RSU =
    1u;
  static constexpr uint8_t EQUIPMENT_TYPE_OBU =
    2u;
  static constexpr uint8_t EQUIPMENT_TYPE_VRU =
    3u;

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__SensorDataSharingMessage
    std::shared_ptr<sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__SensorDataSharingMessage
    std::shared_ptr<sdsm_msgs::msg::SensorDataSharingMessage_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SensorDataSharingMessage_ & other) const
  {
    if (this->msg_cnt != other.msg_cnt) {
      return false;
    }
    if (this->source_id != other.source_id) {
      return false;
    }
    if (this->equipment_type != other.equipment_type) {
      return false;
    }
    if (this->sdsm_time_stamp != other.sdsm_time_stamp) {
      return false;
    }
    if (this->ref_pos != other.ref_pos) {
      return false;
    }
    if (this->objects != other.objects) {
      return false;
    }
    return true;
  }
  bool operator!=(const SensorDataSharingMessage_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SensorDataSharingMessage_

// alias to use template instance with default allocator
using SensorDataSharingMessage =
  sdsm_msgs::msg::SensorDataSharingMessage_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t SensorDataSharingMessage_<ContainerAllocator>::EQUIPMENT_TYPE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t SensorDataSharingMessage_<ContainerAllocator>::EQUIPMENT_TYPE_RSU;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t SensorDataSharingMessage_<ContainerAllocator>::EQUIPMENT_TYPE_OBU;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t SensorDataSharingMessage_<ContainerAllocator>::EQUIPMENT_TYPE_VRU;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__STRUCT_HPP_
