// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sdsm_msgs:msg\SensorDataSharingMessage.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/sensor_data_sharing_message.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__BUILDER_HPP_
#define SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sdsm_msgs/msg/detail/sensor_data_sharing_message__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sdsm_msgs
{

namespace msg
{

namespace builder
{

class Init_SensorDataSharingMessage_objects
{
public:
  explicit Init_SensorDataSharingMessage_objects(::sdsm_msgs::msg::SensorDataSharingMessage & msg)
  : msg_(msg)
  {}
  ::sdsm_msgs::msg::SensorDataSharingMessage objects(::sdsm_msgs::msg::SensorDataSharingMessage::_objects_type arg)
  {
    msg_.objects = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sdsm_msgs::msg::SensorDataSharingMessage msg_;
};

class Init_SensorDataSharingMessage_ref_pos
{
public:
  explicit Init_SensorDataSharingMessage_ref_pos(::sdsm_msgs::msg::SensorDataSharingMessage & msg)
  : msg_(msg)
  {}
  Init_SensorDataSharingMessage_objects ref_pos(::sdsm_msgs::msg::SensorDataSharingMessage::_ref_pos_type arg)
  {
    msg_.ref_pos = std::move(arg);
    return Init_SensorDataSharingMessage_objects(msg_);
  }

private:
  ::sdsm_msgs::msg::SensorDataSharingMessage msg_;
};

class Init_SensorDataSharingMessage_sdsm_time_stamp
{
public:
  explicit Init_SensorDataSharingMessage_sdsm_time_stamp(::sdsm_msgs::msg::SensorDataSharingMessage & msg)
  : msg_(msg)
  {}
  Init_SensorDataSharingMessage_ref_pos sdsm_time_stamp(::sdsm_msgs::msg::SensorDataSharingMessage::_sdsm_time_stamp_type arg)
  {
    msg_.sdsm_time_stamp = std::move(arg);
    return Init_SensorDataSharingMessage_ref_pos(msg_);
  }

private:
  ::sdsm_msgs::msg::SensorDataSharingMessage msg_;
};

class Init_SensorDataSharingMessage_equipment_type
{
public:
  explicit Init_SensorDataSharingMessage_equipment_type(::sdsm_msgs::msg::SensorDataSharingMessage & msg)
  : msg_(msg)
  {}
  Init_SensorDataSharingMessage_sdsm_time_stamp equipment_type(::sdsm_msgs::msg::SensorDataSharingMessage::_equipment_type_type arg)
  {
    msg_.equipment_type = std::move(arg);
    return Init_SensorDataSharingMessage_sdsm_time_stamp(msg_);
  }

private:
  ::sdsm_msgs::msg::SensorDataSharingMessage msg_;
};

class Init_SensorDataSharingMessage_source_id
{
public:
  explicit Init_SensorDataSharingMessage_source_id(::sdsm_msgs::msg::SensorDataSharingMessage & msg)
  : msg_(msg)
  {}
  Init_SensorDataSharingMessage_equipment_type source_id(::sdsm_msgs::msg::SensorDataSharingMessage::_source_id_type arg)
  {
    msg_.source_id = std::move(arg);
    return Init_SensorDataSharingMessage_equipment_type(msg_);
  }

private:
  ::sdsm_msgs::msg::SensorDataSharingMessage msg_;
};

class Init_SensorDataSharingMessage_msg_cnt
{
public:
  Init_SensorDataSharingMessage_msg_cnt()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SensorDataSharingMessage_source_id msg_cnt(::sdsm_msgs::msg::SensorDataSharingMessage::_msg_cnt_type arg)
  {
    msg_.msg_cnt = std::move(arg);
    return Init_SensorDataSharingMessage_source_id(msg_);
  }

private:
  ::sdsm_msgs::msg::SensorDataSharingMessage msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sdsm_msgs::msg::SensorDataSharingMessage>()
{
  return sdsm_msgs::msg::builder::Init_SensorDataSharingMessage_msg_cnt();
}

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__SENSOR_DATA_SHARING_MESSAGE__BUILDER_HPP_
