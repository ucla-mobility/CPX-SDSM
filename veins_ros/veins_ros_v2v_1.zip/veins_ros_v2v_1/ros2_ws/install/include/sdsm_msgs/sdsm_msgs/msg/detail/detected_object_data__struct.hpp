// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sdsm_msgs:msg\DetectedObjectData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_object_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__STRUCT_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'det_obj_common'
#include "sdsm_msgs/msg/detail/detected_object_common_data__struct.hpp"
// Member 'det_veh'
#include "sdsm_msgs/msg/detail/detected_vehicle_data__struct.hpp"
// Member 'det_vru'
#include "sdsm_msgs/msg/detail/detected_vru_data__struct.hpp"
// Member 'det_obst'
#include "sdsm_msgs/msg/detail/detected_obstacle_data__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sdsm_msgs__msg__DetectedObjectData __attribute__((deprecated))
#else
# define DEPRECATED__sdsm_msgs__msg__DetectedObjectData __declspec(deprecated)
#endif

namespace sdsm_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DetectedObjectData_
{
  using Type = DetectedObjectData_<ContainerAllocator>;

  explicit DetectedObjectData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : det_obj_common(_init),
    det_veh(_init),
    det_vru(_init),
    det_obst(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->det_obj_opt_kind = 0;
    }
  }

  explicit DetectedObjectData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : det_obj_common(_alloc, _init),
    det_veh(_alloc, _init),
    det_vru(_alloc, _init),
    det_obst(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->det_obj_opt_kind = 0;
    }
  }

  // field types and members
  using _det_obj_common_type =
    sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator>;
  _det_obj_common_type det_obj_common;
  using _det_obj_opt_kind_type =
    uint8_t;
  _det_obj_opt_kind_type det_obj_opt_kind;
  using _det_veh_type =
    sdsm_msgs::msg::DetectedVehicleData_<ContainerAllocator>;
  _det_veh_type det_veh;
  using _det_vru_type =
    sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator>;
  _det_vru_type det_vru;
  using _det_obst_type =
    sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator>;
  _det_obst_type det_obst;

  // setters for named parameter idiom
  Type & set__det_obj_common(
    const sdsm_msgs::msg::DetectedObjectCommonData_<ContainerAllocator> & _arg)
  {
    this->det_obj_common = _arg;
    return *this;
  }
  Type & set__det_obj_opt_kind(
    const uint8_t & _arg)
  {
    this->det_obj_opt_kind = _arg;
    return *this;
  }
  Type & set__det_veh(
    const sdsm_msgs::msg::DetectedVehicleData_<ContainerAllocator> & _arg)
  {
    this->det_veh = _arg;
    return *this;
  }
  Type & set__det_vru(
    const sdsm_msgs::msg::DetectedVRUData_<ContainerAllocator> & _arg)
  {
    this->det_vru = _arg;
    return *this;
  }
  Type & set__det_obst(
    const sdsm_msgs::msg::DetectedObstacleData_<ContainerAllocator> & _arg)
  {
    this->det_obst = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t OPT_DATA_NONE =
    0u;
  static constexpr uint8_t OPT_DATA_VEHICLE =
    1u;
  static constexpr uint8_t OPT_DATA_VRU =
    2u;
  static constexpr uint8_t OPT_DATA_OBSTACLE =
    3u;

  // pointer types
  using RawPtr =
    sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator> *;
  using ConstRawPtr =
    const sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sdsm_msgs__msg__DetectedObjectData
    std::shared_ptr<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sdsm_msgs__msg__DetectedObjectData
    std::shared_ptr<sdsm_msgs::msg::DetectedObjectData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DetectedObjectData_ & other) const
  {
    if (this->det_obj_common != other.det_obj_common) {
      return false;
    }
    if (this->det_obj_opt_kind != other.det_obj_opt_kind) {
      return false;
    }
    if (this->det_veh != other.det_veh) {
      return false;
    }
    if (this->det_vru != other.det_vru) {
      return false;
    }
    if (this->det_obst != other.det_obst) {
      return false;
    }
    return true;
  }
  bool operator!=(const DetectedObjectData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DetectedObjectData_

// alias to use template instance with default allocator
using DetectedObjectData =
  sdsm_msgs::msg::DetectedObjectData_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectData_<ContainerAllocator>::OPT_DATA_NONE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectData_<ContainerAllocator>::OPT_DATA_VEHICLE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectData_<ContainerAllocator>::OPT_DATA_VRU;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DetectedObjectData_<ContainerAllocator>::OPT_DATA_OBSTACLE;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace sdsm_msgs

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_OBJECT_DATA__STRUCT_HPP_
