// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sdsm_msgs:msg\DetectedVRUData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/detected_vru_data.hpp"


#ifndef SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__TRAITS_HPP_
#define SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sdsm_msgs/msg/detail/detected_vru_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace sdsm_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DetectedVRUData & msg,
  std::ostream & out)
{
  out << "{";
  // member: basic_type
  {
    out << "basic_type: ";
    rosidl_generator_traits::value_to_yaml(msg.basic_type, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DetectedVRUData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: basic_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "basic_type: ";
    rosidl_generator_traits::value_to_yaml(msg.basic_type, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DetectedVRUData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sdsm_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sdsm_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sdsm_msgs::msg::DetectedVRUData & msg,
  std::ostream & out, size_t indentation = 0)
{
  sdsm_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sdsm_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sdsm_msgs::msg::DetectedVRUData & msg)
{
  return sdsm_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sdsm_msgs::msg::DetectedVRUData>()
{
  return "sdsm_msgs::msg::DetectedVRUData";
}

template<>
inline const char * name<sdsm_msgs::msg::DetectedVRUData>()
{
  return "sdsm_msgs/msg/DetectedVRUData";
}

template<>
struct has_fixed_size<sdsm_msgs::msg::DetectedVRUData>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<sdsm_msgs::msg::DetectedVRUData>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<sdsm_msgs::msg::DetectedVRUData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SDSM_MSGS__MSG__DETAIL__DETECTED_VRU_DATA__TRAITS_HPP_
