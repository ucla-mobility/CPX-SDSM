// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from sdsm_msgs:msg\PositionOffsetXYZ.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "sdsm_msgs/msg/detail/position_offset_xyz__rosidl_typesupport_introspection_c.h"
#include "sdsm_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "sdsm_msgs/msg/detail/position_offset_xyz__functions.h"
#include "sdsm_msgs/msg/detail/position_offset_xyz__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  sdsm_msgs__msg__PositionOffsetXYZ__init(message_memory);
}

void sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_fini_function(void * message_memory)
{
  sdsm_msgs__msg__PositionOffsetXYZ__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_message_member_array[4] = {
  {
    "offset_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sdsm_msgs__msg__PositionOffsetXYZ, offset_x),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "offset_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sdsm_msgs__msg__PositionOffsetXYZ, offset_y),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "offset_z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sdsm_msgs__msg__PositionOffsetXYZ, offset_z),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "has_offset_z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sdsm_msgs__msg__PositionOffsetXYZ, has_offset_z),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_message_members = {
  "sdsm_msgs__msg",  // message namespace
  "PositionOffsetXYZ",  // message name
  4,  // number of fields
  sizeof(sdsm_msgs__msg__PositionOffsetXYZ),
  false,  // has_any_key_member_
  sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_message_member_array,  // message members
  sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_init_function,  // function to initialize message memory (memory has to be allocated)
  sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_message_type_support_handle = {
  0,
  &sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_message_members,
  get_message_typesupport_handle_function,
  &sdsm_msgs__msg__PositionOffsetXYZ__get_type_hash,
  &sdsm_msgs__msg__PositionOffsetXYZ__get_type_description,
  &sdsm_msgs__msg__PositionOffsetXYZ__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_sdsm_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sdsm_msgs, msg, PositionOffsetXYZ)() {
  if (!sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_message_type_support_handle.typesupport_identifier) {
    sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &sdsm_msgs__msg__PositionOffsetXYZ__rosidl_typesupport_introspection_c__PositionOffsetXYZ_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
