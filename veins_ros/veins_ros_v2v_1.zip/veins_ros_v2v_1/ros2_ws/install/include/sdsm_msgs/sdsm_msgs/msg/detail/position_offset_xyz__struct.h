// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sdsm_msgs:msg\PositionOffsetXYZ.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sdsm_msgs/msg/position_offset_xyz.h"


#ifndef SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__STRUCT_H_
#define SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/PositionOffsetXYZ in the package sdsm_msgs.
/**
  * Position offset relative to refPos
  * Relative coordinates avoid coordinate system conversions and improve precision
 */
typedef struct sdsm_msgs__msg__PositionOffsetXYZ
{
  /// X offset (0.1 m units)
  /// Lateral offset from sender (left/right)
  int16_t offset_x;
  /// Y offset (0.1 m units)
  /// Longitudinal offset from sender (forward/backward)
  int16_t offset_y;
  /// Z offset (0.1 m units)
  /// Vertical offset; optional because most objects are on ground plane
  int16_t offset_z;
  bool has_offset_z;
} sdsm_msgs__msg__PositionOffsetXYZ;

// Struct for a sequence of sdsm_msgs__msg__PositionOffsetXYZ.
typedef struct sdsm_msgs__msg__PositionOffsetXYZ__Sequence
{
  sdsm_msgs__msg__PositionOffsetXYZ * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sdsm_msgs__msg__PositionOffsetXYZ__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SDSM_MSGS__MSG__DETAIL__POSITION_OFFSET_XYZ__STRUCT_H_
