#!/usr/bin/env python3
"""Small CLI helper (no ROS) to send a single UDP command to Veins.

Usage:
  python3 -m veins_ros_bridge.send_cmd --id 0 --cmd "PING"
  python3 -m veins_ros_bridge.send_cmd --id 1 --cmd "SEND_BSM hello"

This is handy for quick testing before ROS topics.
"""

import argparse
import socket


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='127.0.0.1')
    p.add_argument('--cmd_port_base', type=int, default=50000)
    p.add_argument('--id', type=int, default=0)
    p.add_argument('--cmd', required=True)
    args = p.parse_args()

    port = args.cmd_port_base + args.id
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.sendto(args.cmd.encode('utf-8'), (args.host, port))
    print(f"sent to {args.host}:{port}: {args.cmd}")


if __name__ == '__main__':
    main()
