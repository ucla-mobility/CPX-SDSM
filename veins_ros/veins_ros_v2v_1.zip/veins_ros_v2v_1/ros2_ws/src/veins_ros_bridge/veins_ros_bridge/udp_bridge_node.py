#!/usr/bin/env python3

import socket
import select
import json
from typing import Tuple

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

try:
    from sdsm_msgs.msg import SensorDataSharingMessage
    from rosidl_runtime_py.convert import message_to_ordereddict
    _HAS_SDSM = True
except Exception:
    SensorDataSharingMessage = None  # type: ignore
    message_to_ordereddict = None  # type: ignore
    _HAS_SDSM = False


class VeinsUdpBridge(Node):
    """Bridge between ROS 2 and Veins (OMNeT++) via UDP.

    Veins side (each vehicle):
      - listens for commands on UDP port: (cmd_port_base + nodeIndex)
      - sends RX/TX/ACK to ROS host:ros_rx_port

    ROS side (this node):
      - subscribes /veins/cmd_raw (std_msgs/String)
      - publishes   /veins/rx_raw  (std_msgs/String)

    cmd_raw format (two options):
      1) "<id> <COMMAND> [args...]"  e.g.  "0 SEND_BSM hello"
      2) "<COMMAND> [args...]"      (will use default_target_id)

    Example commands supported by RosSDSMApp:
      - PING
      - SEND_BSM <payload...>
      - SET_INTERVAL <seconds>
      - ENABLE_PERIODIC <0|1>
    """

    def __init__(self):
        super().__init__('veins_udp_bridge')

        self.declare_parameter('host', '127.0.0.1')
        self.declare_parameter('cmd_port_base', 50000)
        self.declare_parameter('ros_rx_port', 50010)
        self.declare_parameter('default_target_id', 0)
        if _HAS_SDSM:
            self.declare_parameter('sdsm_target_id', 0)

        self.host = self.get_parameter('host').get_parameter_value().string_value
        self.cmd_port_base = self.get_parameter('cmd_port_base').get_parameter_value().integer_value
        self.ros_rx_port = self.get_parameter('ros_rx_port').get_parameter_value().integer_value
        self.default_target_id = self.get_parameter('default_target_id').get_parameter_value().integer_value
        self.sdsm_target_id = self.get_parameter('sdsm_target_id').get_parameter_value().integer_value if _HAS_SDSM else 0

        # UDP socket to receive telemetry from Veins
        self.rx_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.rx_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.rx_sock.bind(('0.0.0.0', self.ros_rx_port))
        self.rx_sock.setblocking(False)

        # Separate socket for sending commands
        self.tx_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.pub_rx = self.create_publisher(String, '/veins/rx_raw', 10)
        self.sub_cmd = self.create_subscription(String, '/veins/cmd_raw', self.on_cmd, 10)

        # Optional: publish a real SDSM message to `/veins/sdsm_tx` (type: sdsm_msgs/SensorDataSharingMessage)
        if _HAS_SDSM:
            self.sub_sdsm = self.create_subscription(
                SensorDataSharingMessage,
                '/veins/sdsm_tx',
                self.on_sdsm,
                10,
            )
        else:
            self.sub_sdsm = None

        self.timer = self.create_timer(0.02, self.poll_rx)

        self.get_logger().info(
            f"UDP bridge started. Veins commands: {self.host}:(cmd_port_base+id), "
            f"ROS rx_port={self.ros_rx_port}, default_target_id={self.default_target_id}"
        )
        if _HAS_SDSM:
            self.get_logger().info(
                f"SDSM topic enabled: /veins/sdsm_tx -> SEND_BSM (target_id={self.sdsm_target_id})"
            )
        else:
            self.get_logger().info(
                "SDSM topic disabled (sdsm_msgs not found). Only /veins/cmd_raw is available."
            )

    def _parse_cmd(self, data: str) -> Tuple[int, str]:
        data = data.strip()
        if not data:
            return self.default_target_id, ''

        parts = data.split(' ', 1)
        if len(parts) == 2 and parts[0].isdigit():
            return int(parts[0]), parts[1].strip()
        return self.default_target_id, data

    def on_cmd(self, msg: String):
        target_id, cmdline = self._parse_cmd(msg.data)
        if not cmdline:
            return
        port = int(self.cmd_port_base + target_id)
        self.tx_sock.sendto(cmdline.encode('utf-8'), (self.host, port))
        self.get_logger().info(f"-> Veins node[{target_id}] @ {self.host}:{port}: {cmdline}")

    def poll_rx(self):
        # Drain all pending datagrams
        while True:
            try:
                data, addr = self.rx_sock.recvfrom(4096)
            except BlockingIOError:
                break
            except OSError:
                break

            text = data.decode('utf-8', errors='replace').strip()
            out = String()
            out.data = text
            self.pub_rx.publish(out)

            # Keep log concise
            self.get_logger().info(f"<- Veins {addr[0]}:{addr[1]}: {text}")

    def on_sdsm(self, msg):
        """Convert SDSM ROS message to a JSON payload string and send to Veins."""
        target_id = int(self.sdsm_target_id)
        port = int(self.cmd_port_base + target_id)

        payload = None
        if message_to_ordereddict is not None:
            try:
                payload = json.dumps(message_to_ordereddict(msg), separators=(',', ':'), ensure_ascii=False)
            except Exception:
                payload = None
        if payload is None:
            payload = str(msg)

        cmdline = f"SEND_BSM {payload}"
        self.tx_sock.sendto(cmdline.encode('utf-8'), (self.host, port))
        self.get_logger().info(f"-> Veins node[{target_id}] @ {self.host}:{port}: SEND_BSM <sdsm_json>")


def main():
    rclpy.init()
    node = VeinsUdpBridge()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
