# veins_ros_bridge

A minimal UDP bridge to **control Veins (OMNeT++) V2V communication from ROS 2**.

## Port convention
- Each Veins vehicle listens on UDP port:
  `cmd_port_base + nodeIndex`
  - node[0] -> 50000
  - node[1] -> 50001
- Veins sends RX/TX/ACK back to ROS on:
  `ros_rx_port` (default 50010)

## ROS topics
- Subscribe: `/veins/cmd_raw` (`std_msgs/String`)
  - Format: `"<id> <COMMAND> [args...]"`
- Publish: `/veins/rx_raw` (`std_msgs/String`)

Optional (if `sdsm_msgs` is built in the same workspace):
- Subscribe: `/veins/sdsm_tx` (`sdsm_msgs/SensorDataSharingMessage`)
  - The bridge will serialize the message to JSON and send it as `SEND_BSM <json>`
  - Target vehicle is selected by parameter `sdsm_target_id` (default 0)

## Example
```bash
ros2 run veins_ros_bridge udp_bridge
ros2 topic pub /veins/cmd_raw std_msgs/String "data: '0 PING'"
ros2 topic pub /veins/cmd_raw std_msgs/String "data: '0 ENABLE_PERIODIC 0'"
ros2 topic pub /veins/cmd_raw std_msgs/String "data: '0 SEND_BSM hello_from_ros'"
```
