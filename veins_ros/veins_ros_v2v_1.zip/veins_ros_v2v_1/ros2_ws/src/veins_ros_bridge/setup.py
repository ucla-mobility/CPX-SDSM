from setuptools import setup

package_name = 'veins_ros_bridge'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/udp_bridge.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Lab Maintainer',
    maintainer_email='lab@example.edu',
    description='ROS 2 <-> Veins UDP bridge',
    license='BSD-3-Clause',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'udp_bridge = veins_ros_bridge.udp_bridge_node:main',
            'send_cmd = veins_ros_bridge.send_cmd:main',
        ],
    },
)
