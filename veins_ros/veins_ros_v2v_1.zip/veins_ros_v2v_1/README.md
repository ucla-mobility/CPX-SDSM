# veins_ros_v2v (Veins 5.2 + SUMO 1.8.0) — 最小 V2V SDSM-like Demo

这个项目目标：在 **Veins (SUMO+OMNeT++ Co-simulation)** 的最小场景中，让两辆车周期性广播一条 "SDSM-like" 消息，实现最基础的 V2V 通信链路验证。

> 你现在的 Veins NED package 是 `org.car2x.veins...`（官方 Veins 5.x 系列默认），本项目已按该包名修正。

---

## 目录结构
- `simulations/`：OMNeT++ 场景（NED + omnetpp.ini）
- `src/`：应用层代码 `RosSDSMApp`（继承 DemoBaseApplLayer，发/收 BSM）
- `src/messages/`：自定义消息 `SdsmPayload.msg`（被封装在 DemoSafetyMessage 里）
- `sumo/`：SUMO 最小路网 + routes + cfg + build_net 脚本
- `ros/ROS/`：SDSM 相关 ROS2 msg（可选，仅用于对照字段/后续桥接）

---

## 前置条件（你已基本完成）
1. Veins 示例 `examples/veins` 能在 Qtenv 跑通 ✅
2. SUMO_HOME 正确：`D:\sim\sumo-1.8.0`（并且 `sumo.exe`、`netconvert.exe` 可用）

---

## Step 1：放置项目
把整个 `veins_ros_v2v` 文件夹放到你的 OMNeT++ workspace 下，例如：

- `D:\sim\ws_omnetpp\veins_ros_v2v`

然后在 OMNeT++ IDE：

- `File -> Import -> Existing Projects from File System`
- 选到 `D:\sim\ws_omnetpp` 或 `...\veins_ros_v2v`

---

## Step 2：配置项目引用（非常重要）
右键 `veins_ros_v2v` -> `Properties`：

1) **Project References**
- 勾选你的 `veins` 项目（也就是 Veins 5.2 的工程）

2) **OMNeT++ -> Makemake**
- 选中 `veins_ros_v2v` 工程根目录或 `src/`
- `Build` 选择 **Makemake**
- 点击 `Apply`，然后右键项目 `Build Project`

> 如果你之前 `Makemake` 选成了 "No Makefile"，一定要改回 Makemake。

---

## Step 3：Run Configuration（推荐配置）
在 IDE：`Run -> Run Configurations -> OMNeT++ Simulation`

- **Executable**：选择编译出来的 `veins_ros_v2v` 可执行文件（例如 `.../veins_ros_v2v.exe`）
- **Working dir**：`veins_ros_v2v/simulations`
- **Ini file(s)**：`omnetpp.ini`

### Advanced
- **Dynamic libraries**：`${opp_shared_libs:/veins}`
- **NED Source Path**：`${opp_ned_path:/veins_ros_v2v};${opp_ned_path:/veins}`
- **Image Path**：`${opp_image_path:/veins}`

---

## Step 4：运行
- 直接 Run（Qtenv 或 Cmdenv 均可）
- 如果 SUMO 能正常拉起，你会在 Console 看到 TraCI 连接成功，并在日志里看到类似：

```
[RosSDSMApp] RX BSM latency=... payload="SensorDataSharingMessage{...}"
```

---

# 使用 ROS 2 控制 Veins 中的通信（UDP Bridge）

本项目采用 **Veins <-> ROS2 通过 UDP 通信** 的集成方式：
- **Veins 侧**只依赖标准 socket（Windows: Winsock），不需要把 ROS2 链接进 OMNeT++ 工程
- **ROS2 侧**运行一个 `veins_ros_bridge` 节点，把 ROS topic 转成 UDP 命令，再接收 Veins 的 RX/TX/ACK 回传

## 1) 端口约定
- 每辆车（每个 `node[i]`）监听一个命令端口：
  - `cmd_port = rosCmdPortBase + nodeIndex`
  - 默认：node[0] -> 50000，node[1] -> 50001
- 车辆向 ROS2 回传的端口（所有车共用一个目标端口）：
  - `rosRemotePort`（默认 50010）

这些参数都在 `simulations/omnetpp.ini` 里可配置：
```
*.node[*].appl.rosCmdPortBase = 50000
*.node[*].appl.rosRemoteHost = "127.0.0.1"
*.node[*].appl.rosRemotePort = 50010
```

## 2) ROS2 工作空间（已提供）
在工程根目录 `ros2_ws/` 下包含：
- `sdsm_msgs`：SDSM 消息定义（你已有的那个包）
- `veins_ros_bridge`：UDP Bridge 节点

## 3) 运行顺序（推荐）
1. **启动 Veins 仿真**（IDE Run）
2. **启动 ROS2 bridge**
3. 在 ROS2 里发布控制命令（例如让 node[0] 立即发送）

## 4) ROS2 bridge 运行示例
（Windows / Linux 都一样，先 source 你的 ROS2 环境）

```bash
cd ros2_ws
colcon build
source install/setup.bash   # Windows 用 install\setup.bat

ros2 run veins_ros_bridge udp_bridge \
  --ros-args -p host:=127.0.0.1 -p cmd_port_base:=50000 -p ros_rx_port:=50010
```

另开一个终端发布控制命令：
```bash
# 让 node[0] 立即发送一条 payload="hello"
ros2 topic pub --once /veins/cmd_raw std_msgs/msg/String "{data: '0 SEND_BSM hello'}"

# 关闭 node[0] 周期发送
ros2 topic pub --once /veins/cmd_raw std_msgs/msg/String "{data: '0 ENABLE_PERIODIC 0'}"

# 修改 node[1] 周期发送间隔为 0.2s
ros2 topic pub --once /veins/cmd_raw std_msgs/msg/String "{data: '1 SET_INTERVAL 0.2'}"
```

你会在 bridge 终端看到 Veins 回传的 `HELLO / ACK / TX / RX` 文本，同时也会被发布到：
- `/veins/rx_raw` (std_msgs/String)

## 5) 非 ROS 测试（可选）
如果你想先确认 UDP 通了，再上 ROS：
```bash
cd ros2_ws
python3 -m veins_ros_bridge.send_cmd --id 0 --cmd "PING"
python3 -m veins_ros_bridge.send_cmd --id 1 --cmd "SEND_BSM test_payload"
```

---

## SUMO 路网生成（可选）
如果你想自己改 nodes/edges 后重新生成 net：

```bat
cd sumo
set SUMO_HOME=D:\sim\sumo-1.8.0
build_net.bat
```

---

## 已做的关键修复（针对你之前遇到的报错）
1. **NED 包名统一为 `org.car2x.veins...`**（否则会出现 missing base type / package mismatch）
2. `SdsmPayload.msg` 使用 OMNeT++ 正确语法：`namespace ...;`（不是 `package ...;`）
3. 网络 NED 补齐 `ConnectionManager / World / AnnotationManager / ObstacleControl`，避免最小网络缺组件
4. `omnetpp.ini` 默认 SUMO 路径更新为 `D:/sim/sumo-1.8.0/...` 并添加 `--remote-port $port`

