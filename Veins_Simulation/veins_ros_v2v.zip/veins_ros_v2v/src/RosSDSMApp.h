#ifndef __VEINS_ROS_V2V_ROSSDSMAPP_H_
#define __VEINS_ROS_V2V_ROSSDSMAPP_H_

#include <omnetpp.h>
#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"
#include "veins/modules/messages/DemoSafetyMessage_m.h"
#include "messages/SdsmPayload_m.h"

namespace veins_ros_v2v {

/**
 * Minimal V2V demo app (Veins 5.2+):
 * - Every vehicle periodically broadcasts a DemoSafetyMessage (BSM beacon)
 * - We attach our own payload by encapsulating a SdsmPayload packet into the BSM
 * - Receivers log payload and one-way latency (simTime - timestamp)
 */
class RosSDSMApp : public veins::DemoBaseApplLayer {
public:
    RosSDSMApp();
    virtual ~RosSDSMApp();

protected:
    virtual void initialize(int stage) override;
    virtual void finish() override;

    virtual void onBSM(veins::DemoSafetyMessage* bsm) override;
    virtual void handleSelfMsg(cMessage* msg) override;

private:
    void sendSdsmOnce();

private:
    cMessage* sendTimer_ = nullptr;
    simtime_t sendInterval_;
    long sent_ = 0;
    long received_ = 0;
};

} // namespace veins_ros_v2v

#endif
