#include "RosSDSMApp.h"

using namespace omnetpp;

namespace veins_ros_v2v {

Define_Module(RosSDSMApp);

RosSDSMApp::RosSDSMApp() {}

RosSDSMApp::~RosSDSMApp() {
    cancelAndDelete(sendTimer_);
    sendTimer_ = nullptr;
}

void RosSDSMApp::initialize(int stage) {
    DemoBaseApplLayer::initialize(stage);

    if (stage == 0) {
        sendInterval_ = par("sendInterval");
        sendTimer_ = new cMessage("sdsmSendTimer");
        sent_ = received_ = 0;
    }

    if (stage == 1) {
        scheduleAt(simTime() + uniform(0.1, 0.3), sendTimer_);
    }
}

void RosSDSMApp::handleSelfMsg(cMessage* msg) {
    if (msg == sendTimer_) {
        sendSdsmOnce();
        scheduleAt(simTime() + sendInterval_, sendTimer_);
        return;
    }
    DemoBaseApplLayer::handleSelfMsg(msg);
}

void RosSDSMApp::sendSdsmOnce() {
    // BSM beacon (DemoSafetyMessage) exists in Veins 5.2+ and is handled by onBSM()
    auto* bsm = new veins::DemoSafetyMessage("SDSM_BSM");
    populateWSM(bsm);
    bsm->setTimestamp(simTime());

    // Build a minimal SDSM-like payload (string) and encapsulate it
    const auto pos = mobility->getPositionAt(simTime());
    const double spd = mobility->getSpeed();

    std::ostringstream oss;
    oss << "SensorDataSharingMessage{"
        << "veh=\"" << getParentModule()->getFullName() << "\""
        << ",t=" << simTime().dbl()
        << ",x=" << pos.x
        << ",y=" << pos.y
        << ",speed=" << spd
        << "}";

    auto* payload = new veins_ros_v2v::messages::SdsmPayload("sdsmPayload");
    payload->setPayload(oss.str().c_str());
    bsm->encapsulate(payload);

    sendDown(bsm);
    sent_++;
}

void RosSDSMApp::onBSM(veins::DemoSafetyMessage* bsm) {
    received_++;

    const simtime_t lat = simTime() - bsm->getTimestamp();

    // Our payload is encapsulated inside the BSM
    const cPacket* enc = bsm->getEncapsulatedPacket();
    if (enc) {
        auto* p = check_and_cast<const veins_ros_v2v::messages::SdsmPayload*>(enc);
        EV_INFO << "[RosSDSMApp] RX BSM latency=" << lat
                << " payload=\"" << p->getPayload() << "\"\n";
    } else {
        EV_INFO << "[RosSDSMApp] RX BSM latency=" << lat
                << " (no encapsulated payload)\n";
    }
}

void RosSDSMApp::finish() {
    recordScalar("sdsm_sent", sent_);
    recordScalar("sdsm_received", received_);
    DemoBaseApplLayer::finish();
}

} // namespace veins_ros_v2v
