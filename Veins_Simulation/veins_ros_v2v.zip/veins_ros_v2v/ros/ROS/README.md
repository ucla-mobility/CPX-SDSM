# sdsm_msgs

ROS 2 message definitions for SAE J3224 Sensor Data Sharing Message (SDSM).

Implements GREEN-priority fields from the SDSM-ROS mapping specification.

## Building

```bash
colcon build --packages-select sdsm_msgs
```
